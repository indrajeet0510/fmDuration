'use strict';

/**
 * @ngdoc function
 * @name iCuttFrontApp.controller:PasswordResetCtrl
 * @description
 * # PasswordResetCtrl
 * Controller of the iCuttFrontApp
 */
angular.module('iCuttFrontApp')
  .controller('PasswordResetCtrl', function ($scope,$http,$stateParams,API_URL, Authentication) {

    /**
     * Both are POST methods
     * @type {string}
       */

    $scope.password = '';
    $scope.rePassword = '';
    $scope.verifyCode = '';

    $scope.resetPasswordProgress = false;
    $scope.linkChecked = false;
    $scope.linkInvalid = true;

    $scope.checkLink = function(){
      $scope.errorMsg = '';
      $scope.successMsg = '';
      $http({
        url : API_URL + 'password_reset_link',
        method : HTTP.POST,
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        data : $.param({
          resetCode : $stateParams.resetCode
        })
      }).then(function(result){
        $scope.linkChecked = true;
        if(result && result.data &&  result.data.status){
          $scope.linkInvalid = false;
          $scope.verifyCode = result.data.data.verifyCode;
        }
        else{
          $scope.errorMsg = (result && result.data && result.data.message) ?  result.data.message : 'Link seems to be invalid';
        }
      },function(err){

        $scope.errorMsg = 'Something went wrong ! Please try again';
      });
    };

    $scope.checkLink();


    $scope.resetPassword = function(){
      $scope.errorMsg = '';
      $scope.successMsg = '';
      $scope.resetPasswordProgress = true;
      $http({
        url : API_URL + 'new_password_update',
        method : HTTP.POST,
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        data : $.param({
          resetCode : $stateParams.resetCode,
          verifyCode : $scope.verifyCode,
          password : $scope.password
        })
      }).then(function(result){
        $scope.resetPasswordProgress = false;
        if(result && result.data &&  result.data.status){
          $scope.successMsg = result.data.message;
        }
        else{
          $scope.errorMsg = (result && result.data && result.data.message) ?  result.data.message : 'Session expired ! Please try again';
        }
      },function(err){
        $scope.resetPasswordProgress = false;
        $scope.errorMsg = 'Something went wrong ! Please try again';
      });
    };

    var verifyResetLink = 'password_reset_link';
    var changeNewPassword = 'new_password_update';






  });
