'use strict';

/**
 * @ngdoc function
 * @name iCuttFrontApp.controller:ChangePasswordCtrl
 * @description
 * # ChangePasswordCtrl
 * Controller of the iCuttFrontApp
 */
angular.module('iCuttFrontApp')
  .controller('ChangePasswordCtrl', function ($scope,$timeout,$state,$stateParams,$http,$mdToast,API_URL, Authentication,PasswordSvc) {

    $scope.isPasswordChangeSuccess = false;
    $scope.changePasswordProgress = false;

    $scope.passwordData = {
      password : '',
      newPassword : '',
      confirmPassword : ''
    };

    var initialPasswordData = angular.copy($scope.passwordData);

    function resetChangePasswordForm (){
      $scope.passwordData = angular.copy(initialPasswordData);
      $scope.changePasswordForm.$setPristine();
      $scope.changePasswordForm.$setUntouched();
    }

    $scope.changePassword = function(){

      $scope.changePasswordProgress = !$scope.changePasswordProgress;

      PasswordSvc.changePassword(Object.assign({},$scope.passwordData)).then(function(resp){
        $scope.changePasswordProgress = !$scope.changePasswordProgress;
        $scope.isPasswordChangeSuccess = true;
        resetChangePasswordForm();
      },function(err){
        $scope.changePasswordProgress = !$scope.changePasswordProgress;
      });

    };

    $timeout(function(){
      angular.element("input[name='password']").focus();
    },300);

  });
