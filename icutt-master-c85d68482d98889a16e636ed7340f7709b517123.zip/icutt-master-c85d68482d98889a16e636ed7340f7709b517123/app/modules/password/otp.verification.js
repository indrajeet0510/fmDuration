'use strict';

/**
 * @ngdoc function
 * @name iCuttFrontApp.controller:OtpVerificationCtrl
 * @description
 * # OtpVerificationCtrl
 * Controller of the iCuttFrontApp
 */
angular.module('iCuttFrontApp')
  .controller('OtpVerificationCtrl', function ($scope,$timeout,$state,$mdToast, $stateParams,PasswordSvc) {

    //Test mobile number
    //7665100759
    console.log($stateParams);

    $scope.isPasswordChangeSuccess = false;
    $scope.validateOtpProgress = false;
    $scope.isOtpTimedOut = false;
    $scope.resendOtpProgress = false;
    $scope.changePasswordProgress = false;

    $scope.isOtpChecked = false;
    $scope.isOtpValid = false;

    $scope.otpData = {
      userType : $stateParams.ut, // User type
      loginId : $stateParams.id, // Login Id
      otp : '',
      secretCode : '',
      password : ''
    };

    $timeout(function(){
      $scope.isOtpTimedOut = !$scope.isOtpTimedOut;
    },60000);

    $scope.validateOtp = function(){
      $scope.validateOtpProgress = !$scope.validateOtpProgress ;
      PasswordSvc.validateOtp(Object.assign({},$scope.otpData)).then(function(resp){
        $scope.validateOtpProgress = !$scope.validateOtpProgress ;
        console.log('OTP Verification Response',resp);
        $scope.otpData.secretCode = resp.data.secretCode;
        $scope.isOtpChecked = true;
        $scope.isOtpValid = true;

      },function(err){
        $scope.validateOtpProgress = !$scope.validateOtpProgress ;
        $scope.isOtpChecked = true;
      });
    };

    $scope.resendOtp = function(){
      $scope.resendOtpProgress = !$scope.resendOtpProgress;

      PasswordSvc.requestOtp(Object.assign({},$scope.otpData)).then(function(resp){
        $scope.resendOtpProgress = !$scope.resendOtpProgress;
      },function(err){
        $scope.resendOtpProgress = !$scope.resendOtpProgress;
      });
    };

    $scope.changePassword = function(){

      $scope.changePasswordProgress = !$scope.changePasswordProgress;

      PasswordSvc.updatePassword(Object.assign({},$scope.otpData)).then(function(resp){
        $scope.changePasswordProgress = !$scope.changePasswordProgress;
        $scope.isPasswordChangeSuccess = true;

        $timeout(function(){
          $mdToast.show(
            $mdToast.simple()
              .textContent('Redirecting to login')
              .parent(angular.element('#toastContainer'))
              .position('bottom right' )
              .hideDelay(3000)
          );
        },1000);


        $timeout(function(){
          /**
           * If user is of employer type send him to employer page for login
           */
          $state.go('login');
        },2000);

      },function(err){
        $scope.changePasswordProgress = !$scope.changePasswordProgress;
      });

    };

    $timeout(function(){
      angular.element("input[name='otp']").focus();
    },300);

  });
