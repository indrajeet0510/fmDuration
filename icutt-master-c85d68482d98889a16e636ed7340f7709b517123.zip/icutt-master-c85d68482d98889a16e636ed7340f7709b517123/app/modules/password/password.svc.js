'use strict';

/**
 * @ngdoc function
 * @name iCuttFrontApp.factory:PasswordSvc
 * @description
 * # PasswordSvc
 * Factory of the iCuttFrontApp
 */

angular.module('iCuttFrontApp').factory('PasswordSvc',function($mdToast,$http,$q,API_URL) {

  function requestOtp(dataParams){
    var deferred = $q.defer();
    $http({
      url : API_URL + 'forgot_password',
      method : HTTP.POST,
      data : dataParams
    }).then(function(resp){
      console.debug('requestOtp',resp);

      if(resp && resp.data &&  resp.data.status){

        $mdToast.show(
          $mdToast.simple()
            .textContent(resp.data.message)
            .parent(angular.element('#toastContainer'))
            .position('bottom right' )
            .hideDelay(3000)
        );

        deferred.resolve(resp.data);

      }
      else if(resp && resp.data && resp.data.message && resp.status === 200){
        $mdToast.show(
          $mdToast.simple()
            .textContent(resp.data.message)
            .parent(angular.element('#toastContainer'))
            .position('bottom right' )
            .hideDelay(3000)
            .theme('danger-toast')
        );
        deferred.reject(resp);
      }

    },function(err){
      console.debug(err);


      if(err && err.status &&  err.status != -1){
        $mdToast.show(
          $mdToast.simple()
            .textContent('Something went wrong ! Please try again')
            .parent(angular.element('#toastContainer'))
            .position('bottom right' )
            .hideDelay(3000)
            .theme('danger-toast')
        );

        deferred.reject(err);
      }
      else if(err && err.status === -1){
        $mdToast.show(
          $mdToast.simple()
            .textContent('Please check your connectivity and try again !')
            .parent(angular.element('#toastContainer'))
            .position('bottom right' )
            .hideDelay(3000)
            .theme('warning-toast')
        );

        deferred.reject(err);
      }

    });

    return deferred.promise;
  }

  function validateOtp(dataParams){
    var deferred = $q.defer();

    $http({
      url : API_URL + 'password_verify_otp',
      method : HTTP.POST,
      data : dataParams
    }).then(function(resp){
      console.debug('validateOtp',resp);
      if(resp && resp.data &&  resp.data.status){

        $mdToast.show(
          $mdToast.simple()
            .textContent(resp.data.message)
                        .parent(angular.element('#toastContainer'))
            .position('bottom right' )
            .hideDelay(3000)
        );

        deferred.resolve(resp.data);

      }
      else if(resp && resp.data && resp.data.message && resp.status === 200){
        $mdToast.show(
          $mdToast.simple()
            .textContent(resp.data.message)
            .parent(angular.element('#toastContainer'))
            .position('bottom right' )
            .hideDelay(3000)
            .theme('danger-toast')
        );
        deferred.reject(resp);
      }

    },function(err){
      console.debug(err);


      if(err && err.status &&  err.status != -1){
        $mdToast.show(
          $mdToast.simple()
            .textContent('Something went wrong ! Please try again')
            .parent(angular.element('#toastContainer'))
            .position('bottom right' )
            .hideDelay(3000)
            .theme('danger-toast')
        );
        deferred.reject(err);
      }
      else if(err && err.status === -1){
        $mdToast.show(
          $mdToast.simple()
            .textContent('Please check your connectivity and try again !')
            .parent(angular.element('#toastContainer'))
            .position('bottom right' )
            .hideDelay(3000)
            .theme('warning-toast')
        );
        deferred.reject(err);
      }

    });

    return deferred.promise;
  }

  /**
   * Updating the password in password reset process
   * @param dataParams
   * @returns {Function}
     */
  function updatePassword(dataParams){
    var deferred = $q.defer();
    $http({
      url : API_URL + 'reset_password',
      method : HTTP.POST,
      data : dataParams
    }).then(function(resp){

      if(resp && resp.data &&  resp.data.status){

        $mdToast.show(
          $mdToast.simple()
            .textContent(resp.data.message)
            .parent(angular.element('#toastContainer'))
            .position('bottom right' )
            .hideDelay(3000)
            .theme('success-toast')
        );
        deferred.resolve(resp.data);

      }
      else if(resp && resp.data && resp.data.message && resp.status === 200){
        $mdToast.show(
          $mdToast.simple()
            .textContent(resp.data.message)
            .parent(angular.element('#toastContainer'))
            .position('bottom right' )
            .hideDelay(3000)
            .theme('danger-toast')
        );
        deferred.reject(resp);
      }

    },function(err){
      console.debug(err);


      if(err && err.status &&  err.status != -1){
        $mdToast.show(
          $mdToast.simple()
            .textContent('Something went wrong ! Please try again')
            .parent(angular.element('#toastContainer'))
            .position('bottom right' )
            .hideDelay(3000)
            .theme('danger-toast')
        );
        deferred.reject(err);
      }
      else if(err && err.status === -1){
        $mdToast.show(
          $mdToast.simple()
            .textContent('Please check your connectivity and try again !')
            .parent(angular.element('#toastContainer'))
            .position('bottom right' )
            .hideDelay(3000)
            .theme('warning-toast')
        );
        deferred.reject(err);
      }

    });


    return deferred.promise;
  }

  /**
   * User wants to change his password (user is logged in)
   * @param dataParams
   * @returns {Function}
     */
  function changePassword(dataParams){
    var deferred = $q.defer();
    $http({
      url : API_URL + 'change_password',
      method : HTTP.POST,
      data : dataParams
    }).then(function(resp){

      if(resp && resp.data &&  resp.data.status){

        $mdToast.show(
          $mdToast.simple()
            .textContent(resp.data.message)
            .parent(angular.element('#toastContainer'))
            .position('bottom right' )
            .hideDelay(3000)
            .theme('success-toast')
        );
        deferred.resolve(resp.data);

      }
      else if(resp && resp.data && resp.data.message && resp.status === 200){
        $mdToast.show(
          $mdToast.simple()
            .textContent(resp.data.message)
            .parent(angular.element('#toastContainer'))
            .position('bottom right' )
            .hideDelay(3000)
            .theme('danger-toast')
        );
        deferred.reject(resp);
      }

    },function(err){
      console.debug(err);


      if(err && err.status &&  err.status != -1){
        $mdToast.show(
          $mdToast.simple()
            .textContent('Something went wrong ! Please try again')
            .parent(angular.element('#toastContainer'))
            .position('bottom right' )
            .hideDelay(3000)
            .theme('danger-toast')
        );
        deferred.reject(err);
      }
      else if(err && err.status === -1){
        $mdToast.show(
          $mdToast.simple()
            .textContent('Please check your connectivity and try again !')
            .parent(angular.element('#toastContainer'))
            .position('bottom right' )
            .hideDelay(3000)
            .theme('warning-toast')
        );
        deferred.reject(err);
      }

    });


    return deferred.promise;
  }

  return {
    requestOtp : requestOtp,
    validateOtp : validateOtp,
    updatePassword : updatePassword,
    changePassword : changePassword
  };
});
