'use strict';

/**
 * @ngdoc function
 * @name iCuttFrontApp.controller:ForgotPasswordCtrl
 * @description
 * # ForgotPasswordCtrl
 * Controller of the iCuttFrontApp
 */
angular.module('iCuttFrontApp')
  .controller('ForgotPasswordCtrl', function ($scope,$timeout,$state,$stateParams,$http,$mdToast,API_URL, Authentication,PasswordSvc) {

    $scope.resetPasswordProgress = false;

    $scope.user = {
      userType : ($stateParams.ut) ? $stateParams.ut : 1,
      loginId : ''
    };

    $scope.resetPassword = function(){

      $scope.resetPasswordProgress = !$scope.resetPasswordProgress;
      PasswordSvc.requestOtp(Object.assign({},$scope.user)).then(function(){
        $scope.resetPasswordProgress = !$scope.resetPasswordProgress;
        $state.go("validate_otp", { ut: $scope.user.userType, id : $scope.user.loginId });
      },function(){
        $scope.resetPasswordProgress = !$scope.resetPasswordProgress;
      });

    };

    $timeout(function(){
      angular.element("input[name='loginId']").focus();
    },300);

  });
