'use strict';

/**
 * @ngdoc function
 * @name iCuttFrontApp.controller:CustomerRegisterCtrl
 * @description
 * # CustomerRegisterCtrl
 * Controller of the iCuttFrontApp
 */
angular.module('iCuttFrontApp')
  .controller('CustomerRegisterCtrl', function ($rootScope, $scope,$timeout,$state,$mdToast,$mdDialog,$parse,Authentication) {


    $scope.isFirstTabActive = true;


    $scope.openMapPopup = function(ev){
      $mdDialog.show({
        controller: 'GoogleMapsCtrl',
        templateUrl: 'views/home/google.maps.tmpl.html',
        locals: {
          AddressComponents : angular.copy($scope.user)
        },
        // parent: angular.element(document.body),
        targetEvent: ev,
        // clickOutsideToClose:false,
        fullscreen: true // Only for -xs, -sm breakpoints.
      })
        .then(function(answer) {
          // showConfirmationDialog().then(function(){
          $scope.user.latitude = answer.latitude;
          $scope.user.longitude = answer.longitude;
          $scope.user.locality = answer.locality;
          $scope.user.city = answer.city;
          $scope.user.state = answer.state;
          $scope.user.country = answer.country;
          $scope.user.postalCode = answer.postalCode;


        }, function() {

        });
    };



    $scope.setSecondTabActive = function(){
      $scope.isFirstTabActive = !$scope.isFirstTabActive;
    };

    $scope.setFirstTabActive = function(){
      $scope.isFirstTabActive = !$scope.isFirstTabActive;
    };

    $scope.user = {
      firstName : "",
      lastName : "",
      email : "",
      isdMobile : '+91',
      isdPhone : '+91',
      phone : '',
      mobile : "",
      password : "",
      confirmPassword : "",
      userType : 2,
      customerName : '',
      latitude : null,
      longitude : null,
      address : '',
      locality : '',
      city : '',
      state : '',
      country : '',
      postalCode : ''
    };

    $scope.registerProgress = false;

    $scope.register = function(){
      console.debug('register',$scope.user);
      $scope.registerProgress = true;
      $scope.customerRegisterForm.$setSubmitted();

      var registrationData = angular.copy($scope.user);

      registrationData.cityTitle = registrationData.city;
      registrationData.stateTitle = registrationData.state;
      registrationData.countryTitle = registrationData.country;

      Authentication.register(registrationData).then(function(userData){
        $scope.registerProgress = false;
        console.log('userData',userData);
        $rootScope.$broadcast('loginEvent');
        $state.go('customer.home');
      },function(err){
        console.log('error',err);
        $scope.registerProgress = false;
        if(err && err.status == 200 && err.data && err.data.message ){
          $scope.isFirstTabActive = !$scope.isFirstTabActive;
          $timeout(function(){
            if(err.data.error){
              for (var fieldName in $scope.customerRegisterForm) {
                if(err.data.error.hasOwnProperty(fieldName)){
                  var message = err.data.error[fieldName];
                  var serverError = $parse('customerRegisterForm.'+fieldName+'.$error.serverError');

                  if (!message) {
                    serverError.assign($scope, undefined);
                    $scope.customerRegisterForm[fieldName].$setValidity('serverMessage', true, $scope.customerRegisterForm);

                  }
                  else if(fieldName == 'loginId'){
                    $scope.customerRegisterForm[fieldName].$setValidity('serverMessage', true, $scope.customerRegisterForm);
                  }
                  else {
                    serverError.assign($scope, err.data.error[fieldName]);
                    $scope.customerRegisterForm[fieldName].$setValidity('serverMessage', false, $scope.customerRegisterForm);

                    //$timeout(function(){
                    angular.element("input[name='"+fieldName+"']").focus();
                    //},300);
                  }
                }
              }

              angular.element("input[name='"+fieldName+"']").blur();

              $mdToast.show(
                $mdToast.simple()
                  .textContent(err.data.message)
                  .position('top right' )
                  .hideDelay(3000)
                  .theme('danger-toast')
              );
            }
          });

        }

        else if(err && err.status &&  err.status !== -1){
          $mdToast.show(
            $mdToast.simple()
              .textContent('Something went wrong ! Please try again')
              .position('top right' )
              .hideDelay(3000)
              .theme('danger-toast')
          );
        }
        else if(err && err.status == -1){
          $mdToast.show(
            $mdToast.simple()
              .textContent('Please check your connectivity and try again !')
              .position('top right' )
              .hideDelay(3000)
              .theme('warning-toast')
          );
        }

      });
    };

    $timeout(function(){
      angular.element("input[name='customer']").focus();
    },300);

  });
