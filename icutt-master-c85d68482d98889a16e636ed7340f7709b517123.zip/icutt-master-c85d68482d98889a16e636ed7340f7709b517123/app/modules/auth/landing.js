'use strict';

/**
 * @ngdoc function
 * @name iCuttFrontApp.controller:LandingCtrl
 * @description
 * # AboutCtrl
 * Controller of the iCuttFrontApp
 */
angular.module('iCuttFrontApp')
  .controller('LandingCtrl', function ($rootScope, $scope,$timeout,$state,$mdToast,$parse,Authentication) {


    $scope.errorMsg = "";

    $scope.user = {
      loginId : "",
      password : "",
      userType : 1,
    };

    $scope.loginProgress = false;


    $scope.login = function(){
      $scope.loginProgress = true;
      Authentication.login({
        loginId : $scope.user.loginId,
        userType : $scope.user.userType,
        password : $scope.user.password
      }).then(function(userData){
        $scope.loginProgress = false;
        console.log('userData',userData);
          $rootScope.$broadcast('loginEvent');
          $state.go('home');

      },function(err){
        console.log('error',err);
        $scope.loginProgress = false;
        if(err && err.status == 200 && err.data && err.data.message ){

          if(err.data.error){
            for (var fieldName in $scope.jobseekerLoginForm) {
              if(err.data.error.hasOwnProperty(fieldName)){
                var message = err.data.error[fieldName];
                var serverError = $parse('jobseekerLoginForm.'+fieldName+'.$error.serverError');

                if (!message) {
                  serverError.assign($scope, undefined);
                  $scope.jobseekerLoginForm[fieldName].$setValidity('serverMessage', true, $scope.jobseekerLoginForm);

                }
                else if(fieldName == 'loginId'){
                  $scope.jobseekerLoginForm[fieldName].$setValidity('serverMessage', true, $scope.jobseekerLoginForm);
                }
                else {
                  serverError.assign($scope, err.data.error[fieldName]);
                  $scope.jobseekerLoginForm[fieldName].$setValidity('serverMessage', false, $scope.jobseekerLoginForm);

                  //$timeout(function(){
                    angular.element("input[name='"+fieldName+"']").focus();
                  //},300);
                }
              }
            }

            angular.element("input[name='"+fieldName+"']").blur();


          }

          $mdToast.show(
            $mdToast.simple()
              .textContent(err.data.message)
              .parent(angular.element('#toastContainer'))
              .position('bottom right' )
              .hideDelay(3000)
              .theme('danger-toast')
          );
        }

        else if(err && err.status &&  err.status !== -1){
          $mdToast.show(
            $mdToast.simple()
              .textContent('Something went wrong ! Please try again')
              .parent(angular.element('#toastContainer'))
              .position('bottom right' )
              .hideDelay(3000)
              .theme('danger-toast')
          );
        }
        else if(err && err.status == -1){
          $mdToast.show(
            $mdToast.simple()
              .textContent('Please check your connectivity and try again !')
              .parent(angular.element('#toastContainer'))
              .position('bottom right' )
              .hideDelay(3000)
              .theme('warning-toast')
          );
        }

      });
    };

    $timeout(function(){
      angular.element("input[name='loginId']").focus();
    },300);

  });
