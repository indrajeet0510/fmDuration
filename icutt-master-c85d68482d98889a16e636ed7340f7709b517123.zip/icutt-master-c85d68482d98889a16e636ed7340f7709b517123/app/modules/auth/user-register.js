'use strict';

/**
 * @ngdoc function
 * @name iCuttFrontApp.controller:EndUserRegisterCtrl
 * @description
 * # AboutCtrl
 * Controller of the iCuttFrontApp
 */
angular.module('iCuttFrontApp')
  .controller('EndUserRegisterCtrl', function ($rootScope, $scope,$timeout,$state,$mdToast,$parse,Authentication) {



    $scope.errorMsg = "";

    $scope.user = {
      firstName : "",
      lastName : "",
      email : "",
      isdMobile : '+91',
      mobile : "",
      password : "",
      confirmPassword : "",
      userType : 1
    };

    $scope.registerProgress = false;

    $scope.register = function(){
      $scope.registerProgress = true;
      $scope.userRegisterForm.$setSubmitted();
      Authentication.register($scope.user).then(function(userData){
        $scope.registerProgress = false;
        console.log('userData',userData);
          $rootScope.$broadcast('loginEvent');
          $state.go('home');

      },function(err){
        console.log('error',err);
        $scope.registerProgress = false;
        if(err && err.status == 200 && err.data && err.data.message ){

          if(err.data.error){
            for (var fieldName in $scope.userRegisterForm) {
              if(err.data.error.hasOwnProperty(fieldName)){
                var message = err.data.error[fieldName];
                var serverError = $parse('userRegisterForm.'+fieldName+'.$error.serverError');

                if (!message) {
                  serverError.assign($scope, undefined);
                  $scope.userRegisterForm[fieldName].$setValidity('serverMessage', true, $scope.userRegisterForm);

                }
                else if(fieldName == 'loginId'){
                  $scope.userRegisterForm[fieldName].$setValidity('serverMessage', true, $scope.userRegisterForm);
                }
                else {
                  serverError.assign($scope, err.data.error[fieldName]);
                  $scope.userRegisterForm[fieldName].$setValidity('serverMessage', false, $scope.userRegisterForm);

                  //$timeout(function(){
                    angular.element("input[name='"+fieldName+"']").focus();
                  //},300);
                }
              }
            }

            angular.element("input[name='"+fieldName+"']").blur();


          }

          $mdToast.show(
            $mdToast.simple()
              .textContent(err.data.message)
              .position('top right' )
              .hideDelay(3000)
              .theme('danger-toast')
          );

        }

        else if(err && err.status &&  err.status !== -1){
          $mdToast.show(
            $mdToast.simple()
              .textContent('Something went wrong ! Please try again')
              .position('top right' )
              .hideDelay(3000)
              .theme('danger-toast')
          );
        }
        else if(err && err.status == -1){
          $mdToast.show(
            $mdToast.simple()
              .textContent('Please check your connectivity and try again !')
              .position('top right' )
              .hideDelay(3000)
              .theme('warning-toast')
          );
        }

      });
    };

    $timeout(function(){
      angular.element("input[name='loginId']").focus();
    },300);

  });
