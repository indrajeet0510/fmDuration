'use strict';

/**
 * @ngdoc function
 * @name iCuttFrontApp.controller:CustomerLoginCtrl
 * @description
 * # AboutCtrl
 * Controller of the iCuttFrontApp
 */
angular.module('iCuttFrontApp')
  .controller('CustomerLoginCtrl', function ($rootScope, $scope,$timeout,$state,$mdToast,$parse,Authentication) {


    $scope.errorMsg = "";

    $scope.user = {
      loginId : "",
      password : "",
      userType : 2
    };

    $scope.loginProgress = false;


    $scope.login = function(){
      $scope.loginProgress = true;
      Authentication.login({
        loginId : $scope.user.loginId,
        userType : $scope.user.userType,
        password : $scope.user.password
      }).then(function(userData){
        $scope.loginProgress = false;
        console.log('userData',userData);
          $rootScope.$broadcast('loginEvent');
          $state.go('customer.home');

      },function(err){
        console.log('error',err);
        $scope.loginProgress = false;
        if(err && err.status == 200 && err.data && err.data.message ){

          if(err.data.error){
            for (var fieldName in $scope.customerLoginForm) {
              if(err.data.error.hasOwnProperty(fieldName)){
                var message = err.data.error[fieldName];
                var serverError = $parse('customerLoginForm.'+fieldName+'.$error.serverError');

                if (!message) {
                  serverError.assign($scope, undefined);
                  $scope.customerLoginForm[fieldName].$setValidity('serverMessage', true, $scope.customerLoginForm);

                }
                else if(fieldName == 'loginId'){
                  $scope.customerLoginForm[fieldName].$setValidity('serverMessage', true, $scope.customerLoginForm);
                }
                else {
                  serverError.assign($scope, err.data.error[fieldName]);
                  $scope.customerLoginForm[fieldName].$setValidity('serverMessage', false, $scope.customerLoginForm);

                  //$timeout(function(){
                    angular.element("input[name='"+fieldName+"']").focus();
                  //},300);
                }
              }
            }

            angular.element("input[name='"+fieldName+"']").blur();


          }

          $mdToast.show(
            $mdToast.simple()
              .textContent(err.data.message)
              .parent(angular.element('#toastContainer'))
              .position('bottom right' )
              .hideDelay(3000)
              .theme('danger-toast')
          );
        }

        else if(err && err.status &&  err.status !== -1){
          $mdToast.show(
            $mdToast.simple()
              .textContent('Something went wrong ! Please try again')
              .parent(angular.element('#toastContainer'))
              .position('bottom right' )
              .hideDelay(3000)
              .theme('danger-toast')
          );
        }
        else if(err && err.status == -1){
          $mdToast.show(
            $mdToast.simple()
              .textContent('Please check your connectivity and try again !')
              .parent(angular.element('#toastContainer'))
              .position('bottom right' )
              .hideDelay(3000)
              .theme('warning-toast')
          );
        }

      });
    };

    $timeout(function(){
      angular.element("input[name='loginId']").focus();
    },300);

  });
