'use strict';

/**
 * @ngdoc function
 * @name iCuttFrontApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the iCuttFrontApp
 */
angular.module('iCuttFrontApp')
  .controller('UserHomeCtrl', function ($rootScope,$scope,$state,$timeout,Authentication) {

    $scope.userDetails = Authentication.getUserInfo();

    $state.go('home.profile');

    $rootScope.$on('$stateChangeStart',function(event,toState, toParams){
      if(toState.name == 'home'){
        $state.go('home.profile');
      }
    });

    $scope.navigate = function (to){
      $state.go(to);
    };


  });
