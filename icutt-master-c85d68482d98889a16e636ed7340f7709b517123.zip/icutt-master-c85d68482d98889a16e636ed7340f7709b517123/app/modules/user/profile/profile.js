'use strict';

/**
 * @ngdoc function
 * @name iCuttFrontApp.controller:ProfileCtrl
 * @description
 * # ProfileCtrl
 * Controller of the iCuttFrontApp
 */
angular.module('iCuttFrontApp')
  .controller('ProfileCtrl', function ($scope,$state,$timeout,Authentication) {

    $scope.userDetails = Authentication.getUserInfo();

    var tabList = [
      'primaryInformationTab'
    ];

    $scope.viewsPath = {
      'primaryInformationTab' : 'modules/enduser/primary-information/primary-information.html'
    };

    // By default first tab is active
    $scope.activeTab = tabList[0];

    $scope.navigate = function (to){
      $state.go(to);
    };

    // Setting active tab
    $scope.setActiveTab = function(activeTab){
      $timeout(function(){
        $scope.activeTab = activeTab;
      },1000);
    };

  });
