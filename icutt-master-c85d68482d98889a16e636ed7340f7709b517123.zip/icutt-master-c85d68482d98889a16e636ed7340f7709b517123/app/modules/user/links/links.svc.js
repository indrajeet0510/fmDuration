'use strict';

/**
 * @ngdoc function
 * @name iCuttFrontApp.factory:SocialLinksSvc
 * @description
 * # SocialLinksSvc
 * Factory of the iCuttFrontApp
 */

angular.module('iCuttFrontApp').factory('SocialLinksSvc',function($mdToast,$http,$q,API_URL) {

  /******************************************************************************************************************/
  /********************************************* OPERATOR APIs ******************************************************/
  /******************************************************************************************************************/

  function oLoadSocialLinks(masterEntityId){
    var deferred = $q.defer();
    $http({
      url : API_URL + 'o/jobseeker/'+masterEntityId+'/' + 'social_link',
      method : HTTP.GET
    }).then(function(resp){
      if(resp && resp.data &&  resp.data.status){

        // $mdToast.show(
        //   $mdToast.simple()
        //     .textContent(resp.data.message)
        //     .parent(angular.element('#toastContainer'))
        //     .position('bottom right' )
        //     .hideDelay(3000)
        // );

        deferred.resolve(resp.data);

      }
      else if(resp && resp.data && resp.data.message && resp.status === 200){
        $mdToast.show(
          $mdToast.simple()
            .textContent(resp.data.message)
            .parent(angular.element('#toastContainer'))
            .position('bottom right' )
            .hideDelay(3000)
            .theme('danger-toast')
        );
        deferred.reject(resp);
      }

    },function(err){
      console.debug(err);


      if(err && err.status &&  err.status != -1){
        $mdToast.show(
          $mdToast.simple()
            .textContent('Something went wrong ! Please try again')
            .parent(angular.element('#toastContainer'))
            .position('bottom right' )
            .hideDelay(3000)
            .theme('danger-toast')
        );

        deferred.reject(err);
      }
      else if(err && err.status === -1){
        $mdToast.show(
          $mdToast.simple()
            .textContent('Please check your connectivity and try again !')
            .parent(angular.element('#toastContainer'))
            .position('bottom right' )
            .hideDelay(3000)
            .theme('warning-toast')
        );

        deferred.reject(err);
      }

    });

    return deferred.promise;
  }

  function oSaveSocialLink(masterEntityId,dataParams){
    var deferred = $q.defer();

    $http({
      url : API_URL + 'o/jobseeker/'+masterEntityId+'/' + 'social_link',
      method : HTTP.POST,
      data : dataParams
    }).then(function(resp){

      if(resp && resp.data &&  resp.data.status){

        $mdToast.show(
          $mdToast.simple()
            .textContent(resp.data.message)
            .parent(angular.element('#toastContainer'))
            .position('bottom right' )
            .hideDelay(3000)
            .theme('success-toast')
        );

        deferred.resolve(resp.data);

      }
      else if(resp && resp.data && resp.data.message && resp.status === 200){
        $mdToast.show(
          $mdToast.simple()
            .textContent(resp.data.message)
            .parent(angular.element('#toastContainer'))
            .position('bottom right' )
            .hideDelay(3000)
            .theme('danger-toast')
        );
        deferred.reject(resp);
      }

    },function(err){
      console.debug(err);


      if(err && err.status &&  err.status != -1){
        $mdToast.show(
          $mdToast.simple()
            .textContent('Something went wrong ! Please try again')
            .parent(angular.element('#toastContainer'))
            .position('bottom right' )
            .hideDelay(3000)
            .theme('danger-toast')
        );
        deferred.reject(err);
      }
      else if(err && err.status === -1){
        $mdToast.show(
          $mdToast.simple()
            .textContent('Please check your connectivity and try again !')
            .parent(angular.element('#toastContainer'))
            .position('bottom right' )
            .hideDelay(3000)
            .theme('warning-toast')
        );
        deferred.reject(err);
      }

    });

    return deferred.promise;
  }

  function oDeleteSocialLink(masterEntityId,params){
    var deferred = $q.defer();

    $http({
      url : API_URL + 'o/jobseeker/'+masterEntityId+'/' + 'social_link' + '/' + params.rid,
      method : HTTP.DELETE,
    }).then(function(resp){

      if(resp && resp.data &&  resp.data.status){

        $mdToast.show(
          $mdToast.simple()
            .textContent(resp.data.message)
            .parent(angular.element('#toastContainer'))
            .position('bottom right' )
            .hideDelay(3000)
            .theme('success-toast')
        );

        deferred.resolve(resp.data);

      }
      else if(resp && resp.data && resp.data.message && resp.status === 200){
        $mdToast.show(
          $mdToast.simple()
            .textContent(resp.data.message)
            .parent(angular.element('#toastContainer'))
            .position('bottom right' )
            .hideDelay(3000)
            .theme('danger-toast')
        );
        deferred.reject(resp);
      }

    },function(err){
      console.debug(err);


      if(err && err.status &&  err.status != -1){
        $mdToast.show(
          $mdToast.simple()
            .textContent('Something went wrong ! Please try again')
            .parent(angular.element('#toastContainer'))
            .position('bottom right' )
            .hideDelay(3000)
            .theme('danger-toast')
        );
        deferred.reject(err);
      }
      else if(err && err.status === -1){
        $mdToast.show(
          $mdToast.simple()
            .textContent('Please check your connectivity and try again !')
            .parent(angular.element('#toastContainer'))
            .position('bottom right' )
            .hideDelay(3000)
            .theme('warning-toast')
        );
        deferred.reject(err);
      }

    });

    return deferred.promise;
  }


  /******************************************************************************************************************/
  /********************************************* JOBSEEKER APIs *****************************************************/
  /******************************************************************************************************************/

  function loadSocialLinks(){
    var deferred = $q.defer();
    $http({
      url : API_URL + 'social_link',
      method : HTTP.GET
    }).then(function(resp){
      if(resp && resp.data &&  resp.data.status){

        // $mdToast.show(
        //   $mdToast.simple()
        //     .textContent(resp.data.message)
        //     .parent(angular.element('#toastContainer'))
        //     .position('bottom right' )
        //     .hideDelay(3000)
        // );

        deferred.resolve(resp.data);

      }
      else if(resp && resp.data && resp.data.message && resp.status === 200){
        $mdToast.show(
          $mdToast.simple()
            .textContent(resp.data.message)
            .parent(angular.element('#toastContainer'))
            .position('bottom right' )
            .hideDelay(3000)
            .theme('danger-toast')
        );
        deferred.reject(resp);
      }

    },function(err){
      console.debug(err);


      if(err && err.status &&  err.status != -1){
        $mdToast.show(
          $mdToast.simple()
            .textContent('Something went wrong ! Please try again')
            .parent(angular.element('#toastContainer'))
            .position('bottom right' )
            .hideDelay(3000)
            .theme('danger-toast')
        );

        deferred.reject(err);
      }
      else if(err && err.status === -1){
        $mdToast.show(
          $mdToast.simple()
            .textContent('Please check your connectivity and try again !')
            .parent(angular.element('#toastContainer'))
            .position('bottom right' )
            .hideDelay(3000)
            .theme('warning-toast')
        );

        deferred.reject(err);
      }

    });

    return deferred.promise;
  }

  function saveSocialLink(dataParams){
    var deferred = $q.defer();

    $http({
      url : API_URL + 'social_link',
      method : HTTP.POST,
      data : dataParams
    }).then(function(resp){

      if(resp && resp.data &&  resp.data.status){

        $mdToast.show(
          $mdToast.simple()
            .textContent(resp.data.message)
            .parent(angular.element('#toastContainer'))
            .position('bottom right' )
            .hideDelay(3000)
            .theme('success-toast')
        );

        deferred.resolve(resp.data);

      }
      else if(resp && resp.data && resp.data.message && resp.status === 200){
        $mdToast.show(
          $mdToast.simple()
            .textContent(resp.data.message)
            .parent(angular.element('#toastContainer'))
            .position('bottom right' )
            .hideDelay(3000)
            .theme('danger-toast')
        );
        deferred.reject(resp);
      }

    },function(err){
      console.debug(err);


      if(err && err.status &&  err.status != -1){
        $mdToast.show(
          $mdToast.simple()
            .textContent('Something went wrong ! Please try again')
            .parent(angular.element('#toastContainer'))
            .position('bottom right' )
            .hideDelay(3000)
            .theme('danger-toast')
        );
        deferred.reject(err);
      }
      else if(err && err.status === -1){
        $mdToast.show(
          $mdToast.simple()
            .textContent('Please check your connectivity and try again !')
            .parent(angular.element('#toastContainer'))
            .position('bottom right' )
            .hideDelay(3000)
            .theme('warning-toast')
        );
        deferred.reject(err);
      }

    });

    return deferred.promise;
  }

  function deleteSocialLink(params){
    var deferred = $q.defer();

    $http({
      url : API_URL + 'social_link' + '/' + params.rid,
      method : HTTP.DELETE,
    }).then(function(resp){

      if(resp && resp.data &&  resp.data.status){

        $mdToast.show(
          $mdToast.simple()
            .textContent(resp.data.message)
            .parent(angular.element('#toastContainer'))
            .position('bottom right' )
            .hideDelay(3000)
            .theme('success-toast')
        );

        deferred.resolve(resp.data);

      }
      else if(resp && resp.data && resp.data.message && resp.status === 200){
        $mdToast.show(
          $mdToast.simple()
            .textContent(resp.data.message)
            .parent(angular.element('#toastContainer'))
            .position('bottom right' )
            .hideDelay(3000)
            .theme('danger-toast')
        );
        deferred.reject(resp);
      }

    },function(err){
      console.debug(err);


      if(err && err.status &&  err.status != -1){
        $mdToast.show(
          $mdToast.simple()
            .textContent('Something went wrong ! Please try again')
            .parent(angular.element('#toastContainer'))
            .position('bottom right' )
            .hideDelay(3000)
            .theme('danger-toast')
        );
        deferred.reject(err);
      }
      else if(err && err.status === -1){
        $mdToast.show(
          $mdToast.simple()
            .textContent('Please check your connectivity and try again !')
            .parent(angular.element('#toastContainer'))
            .position('bottom right' )
            .hideDelay(3000)
            .theme('warning-toast')
        );
        deferred.reject(err);
      }

    });

    return deferred.promise;
  }

  /******************************************************************************************************************/
  /********************************************* EXPOSING FUNCTIONs *************************************************/
  /******************************************************************************************************************/

  return {
    saveSocialLink : saveSocialLink,
    loadSocialLinks : loadSocialLinks,
    deleteSocialLink : deleteSocialLink,

    oSaveSocialLink : oSaveSocialLink,
    oLoadSocialLinks : oLoadSocialLinks,
    oDeleteSocialLink : oDeleteSocialLink
  };
});
