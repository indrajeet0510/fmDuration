'use strict';

/**
 * @ngdoc function
 * @name iCuttFrontApp.controller:SocialLinksCtrl
 * @description
 * # SocialLinksCtrl
 * Controller of the iCuttFrontApp
 */
angular.module('iCuttFrontApp')
  .controller('SocialLinksCtrl', function ($scope,$state,$timeout,$q,$mdDialog,Authentication,SocialLinksSvc,InitialSocialLinkList) {

    $scope.userDetails = Authentication.getUserInfo();

    $scope.socialMediaLink = "";
    $scope.socialLinkList = InitialSocialLinkList;

    // Testing
    // $scope.socialLinkList = [
    //   {
    //     rid : 1,
    //     socialMediaLink : 'http://www.google.com'
    //   },
    //   {
    //     rid : 2,
    //     socialMediaLink : 'http://www.facebook.com'
    //   }
    // ];


    function showConfirmationDialog(ev) {
      // Appending dialog to document.body to cover sidenav in docs app

      var deferred = $q.defer();

      var confirm = $mdDialog.confirm()
        .title('Confirmation?')
        .textContent('Are you sure you want to delete')
        .ariaLabel('Confirmation')
        .targetEvent(ev)
        .ok('Yes')
        .cancel('No');

      $mdDialog.show(confirm).then(function() {
        deferred.resolve();
      }, function() {
        deferred.reject();
      });

      return deferred.promise;
    }

    function loadSocialLink(){
      SocialLinksSvc.loadSocialLinks().then(function(resp){
        $scope.socialLinkList = resp.data.socialLinkList;
      },function(){

      });
    }

    $scope.saveSocialLink = function(){
      SocialLinksSvc.saveSocialLink({socialMediaLink : $scope.socialMediaLink}).then(function(){
        $scope.socialMediaLink = "";
        $scope.socialLinkForm.$setPristine();
        loadSocialLink();
      },function(){

      });
    };

    $scope.deleteSocialMediaLink = function(event,rid){

      /**
       * @TODO Open Confirm modal for deletion
       */

      showConfirmationDialog(event).then(function(){
        SocialLinksSvc.deleteSocialLink({rid : rid}).then(function(){
          loadSocialLink();
        },function(){

        });
      },function(){});


    };


  });
