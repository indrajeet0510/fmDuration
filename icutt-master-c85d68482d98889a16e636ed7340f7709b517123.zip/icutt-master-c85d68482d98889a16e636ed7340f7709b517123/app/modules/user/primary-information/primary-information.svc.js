'use strict';

/**
 * @ngdoc function
 * @name iCuttFrontApp.factory:PrimaryInformationSvc
 * @description
 * # PrimaryInformationSvc
 * Controller of the iCuttFrontApp
 */
angular.module('iCuttFrontApp')
  .factory('PrimaryInformationSvc', function ($http,$q,$mdToast,UtilitySvc,API_URL) {

    function oUpdateQCStatus(masterEntityId,qcStatusId){
      var deferred = $q.defer();
      $http({
        url : API_URL + 'o/jobseeker/'+masterEntityId + '/qc_status',
        method : HTTP.POST,
        data : {
          qcStatus : qcStatusId
        }
      }).then(function(resp){
        UtilitySvc.parseSuccessResponse(resp,deferred);
      },function(err){
        UtilitySvc.parseErrorResponse(err,deferred);
      });
      return deferred.promise;
    }

      /**
       * Operator saving primary info
       */
    function oSavePrimaryInfo(masterEntityId,primaryData){
        var deferred = $q.defer();
        $http({
          url : API_URL + 'o/jobseeker/'+masterEntityId+'/primary_info',
          method : HTTP.POST,
          data : primaryData
        }).then(function(resp){
          UtilitySvc.parseSuccessResponse(resp,deferred);
        },function(err){
          UtilitySvc.parseErrorResponse(err,deferred);
        });

        return deferred.promise;
    }

    function savePrimaryInfo(primaryData){
      var deferred = $q.defer();
      $http({
        url : API_URL + 'primary_info',
        method : HTTP.POST,
        data : primaryData
      }).then(function(resp){
        UtilitySvc.parseSuccessResponse(resp,deferred);
      },function(err){
        UtilitySvc.parseErrorResponse(err,deferred);
      });
      return deferred.promise;
    }

    return {
      savePrimaryInfo : savePrimaryInfo,
      oSavePrimaryInfo : oSavePrimaryInfo,
      oUpdateQCStatus : oUpdateQCStatus
    }
  });
