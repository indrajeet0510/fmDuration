'use strict';

/**
 * @ngdoc function
 * @name iCuttFrontApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the iCuttFrontApp
 */
angular.module('iCuttFrontApp')
  .controller('PrimaryInformationCtrl', function ($scope,$timeout,$mdToast,Authentication,PrimaryInformationSvc) {

    $scope.user = Authentication.getUserInfo().jobSeekerResult[0];
    $scope.primaryInformationProgress = false;

    $scope.savePrimaryInformation = function savePrimaryInfo(){
      $scope.primaryInformationProgress = !$scope.primaryInformationProgress;
      PrimaryInformationSvc.savePrimaryInfo($scope.user).then(function(res){
        Authentication.getRemoteUserInfo();
        $scope.primaryInformationProgress = !$scope.primaryInformationProgress;

      },function(err){
        $scope.primaryInformationProgress = !$scope.primaryInformationProgress;
      });
    }
  });
