'use strict';

/**
 * @ngdoc function
 * @name iCuttFrontApp.controller:LoginCtrl
 * @description
 * # AboutCtrl
 * Controller of the iCuttFrontApp
 */
angular.module('iCuttFrontApp')
  .controller('HeaderCtrl', function ($scope,$state,$mdSidenav,Authentication) {

    $scope.toggleLeft = buildToggler('left');
    $scope.toggleRight = buildToggler('right');

    $scope.navigate = function(to){
      $state.go(to);
    };

    $scope.languageList = [
      {
        id : 1,
        title : 'English'
      },
      {
        id : 2,
        title : 'Arabic'
      },
      {
        id : 2,
        title : 'French'
      }
    ];

    /**
     * @TODO
     * Introduce language from service injection
       */
    $scope.selectedLanguage = $scope.languageList[0];

    $scope.selectLanguage = function(index){
      $scope.selectedLanguage = $scope.languageList[index];
    };

    function buildToggler(componentId) {
      return function() {
        $mdSidenav(componentId).toggle();
      }
    }

    $scope.userDetails = Authentication.getUserInfo();

    $scope.$on('loginEvent',function(){
      $scope.userDetails = Authentication.getUserInfo();
    });

    $scope.logout = function(){
      Authentication.logout().then(function(){
        $scope.userDetails = null;
        $state.go('login');
      },function(){

      });
    };

  });
