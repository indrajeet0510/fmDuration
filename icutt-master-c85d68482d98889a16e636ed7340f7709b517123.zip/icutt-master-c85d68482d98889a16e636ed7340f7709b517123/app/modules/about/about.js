'use strict';

/**
 * @ngdoc function
 * @name iCuttFrontApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the iCuttFrontApp
 */
angular.module('iCuttFrontApp')
  .controller('AboutCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
