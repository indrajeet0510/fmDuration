/**
 * Filter for converting datetime from a specific format to some other format
 */
(function(){
  angular.module('iCuttFrontApp').filter('dateTimeFormat',function(){
    /**
     * moment or Date
     */
    return function(dateObj,pFormat,rFormat){

      if(typeof dateObj == 'string'){
        dateObj = new Date(dateObj);
      }

      if(!(dateObj && moment(dateObj).isValid())){
        return '';
      }
      if(!pFormat){
        pFormat = "DD MMM YYYY hh:mm A";
      }
      if(!pFormat){
        rFormat = "DD MMM YYYY hh:mm A";
      }
      var fTime = '';
      try{
        var m = moment(dateObj,pFormat);
        fTime = m.format(rFormat);
      }
      catch(ex){
        console.error('Invalid Time');
      }
      return fTime;
    };
  });
})();


