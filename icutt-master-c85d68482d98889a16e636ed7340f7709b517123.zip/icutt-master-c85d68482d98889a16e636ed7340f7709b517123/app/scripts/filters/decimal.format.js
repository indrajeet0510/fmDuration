'use strict';

/**
 * Filter for truncating String to a specific length
 * @param string
 * @param length to be truncated
 * @usage
 * string | truncate:10
 */

angular.module('iCuttFrontApp').filter('decimalFormat', function () {
  return function (number, decimalPlaces) {
    if(!number || isNaN(parseFloat(number))){
      return 0.00;
    }
    else{
      return parseFloat(number).toFixed((decimalPlaces && (!isNaN(parseInt(decimalPlaces)) && decimalPlaces > 0)) ? decimalPlaces : 2);
    }
  };
});
