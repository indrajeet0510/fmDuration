'use strict';

/**
 * Filter for truncating String to a specific length
 * @param string
 * @param length to be truncated
 * @usage
 * string | truncate:10
 */

angular.module('iCuttFrontApp').filter('qcStatusText', function () {
  return function (value) {
    /**
     * @TODO
     * Get this array from $translate service of angular-translate for language translation
     */
    var qcStatusList = [
      'Pending',
      'Completed'
    ];

    console.log(value);
    if(value && parseInt(value) == 2){

      return qcStatusList[1];
    }
    else {
      return qcStatusList[0];
    }

  };
});
