/**
 * Filter for truncating String to a specific length
 * @param string
 * @param length to be truncated
 * @usage
 * string | truncate:10
 */
angular.module('icuttApp').
  filter('seconds', function () {
    return function (milliseconds) {
      if(!milliseconds){
        return 0;
      }
      if (isNaN(parseInt(milliseconds)))
      {
        return 0;
      }

      var seconds = milliseconds/1000;
      return parseInt(seconds);
    };
  });
