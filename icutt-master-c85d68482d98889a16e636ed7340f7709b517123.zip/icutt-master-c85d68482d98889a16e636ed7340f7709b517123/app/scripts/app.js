'use strict';

var HTTP = {
  GET : 'GET',
  POST : 'POST',
  PUT : 'PUT',
  DELETE : 'DELETE'
};

/**
 * @ngdoc overview
 * @name iCuttFrontApp
 * @description
 * # iCuttFrontApp
 *
 * Main module of the application.
 */

angular
  .module('iCuttFrontApp', [
    'ui.router',
    'ngMaterial',
    'ngSanitize',
    'ngMessages',
    'angular-loading-bar',
    'ngImgCrop',
    'rzModule',
    'pascalprecht.translate' // Angular Translation module for i10n and i18n
  ]);
