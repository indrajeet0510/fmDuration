/**
 * Created by Indra on 19-07-2015.
 */

(function(){
  /**
     * These routes will be password protected, only authenticated users can access these routes
     */
  angular.module('icuttApp')
  /**
    * API Service url
    */

    //.constant('API_URL','http://localhost:3000/api')
    //.constant('API_URL','http://'+location.hostname+ ':3000/api')
    .constant('API_URL',window.API_URL)

    .constant('APP_DOMAIN',window.APP_DOMAIN)

    /**
     * These routes will not be navigated when user is logged in
     * for eg. User cannot open signup page while he is logged in
     */
    .constant('INSECURE_LINKS',[
      '/login',
      '/register'
    ])

    /**
     * These routes will be password protected, only authenticated users can access these routes
     */
    .constant('SECURE_LINKS',[
      '/dashboard',
      '/profile',
      '/profile/password',
      '/domains/:domain_id/ad/:ad_id',
      '/domains/:domain_id/ad',
      '/domains/:domain_id',
      '/domains',
      '/logout'
    ])

  /**
   * These routes will not consider whether user is authenticated or not
   * and user can navigate to these routes as public routes whether logged in or not
   * The only difference between normal open links and this is that it adds up the loginDetails to $rootScope if
   * user is logged in
   */
    .constant('OPEN_LINKS',[
      '/contact',
      '/about'
    ])
    .constant('CONSTANTS', {
      STATIC_AD_URL : window.STATIC_AD_URL,
      ADS: [
        '/images/default-ad.png',
        '/images/default-ad-1.jpg',
        '/images/default-ad-2.jpg',
        '/images/default-ad.png',
        '/images/default-ad.png',
        '/images/default-ad.png',
        '/images/default-ad.png',
        '/images/default-ad.png',
        '/images/default-ad.png',
        '/images/default-ad.png',
        '/images/default-ad.png',
        '/images/default-ad.png',
      ],
      ADS_URL : [
        'http://huss.link/',
        'http://huss.link/',
        'http://huss.link/',
        'http://huss.link/',
        'http://huss.link/',
        'http://huss.link/',
        'http://huss.link/',
        'http://huss.link/',
        'http://huss.link/',
        'http://huss.link/',
        'http://huss.link/',
        'http://huss.link/',
        'http://huss.link/',
      ]
    })

  /**
   * Service for fetching login details from localStorage
   */
    .value('$loginDetails',(function(){
       if(typeof(localStorage) !== "undefined"){
           try {
               var loginDetails = localStorage.getItem("_loginDetails");
               return JSON.parse(loginDetails);
           }
           catch(ex){
               return null;
           }
        }
        else{
            alert('Whoops ! Please upgrade to newer browser');
            return null;
        }
    })());
})();


















