'use strict';

/**
 * @ngdoc function
 * @name icuttApp.config:run
 * @description
 * # Run Block
 * Run Block of the icuttApp
 */
(function(){
  angular.module('icuttApp').run(['$rootScope','$location','SECURE_LINKS','INSECURE_LINKS','OPEN_LINKS','$loginDetails',
    function($rootScope,$location,SECURE_LINKS,INSECURE_LINKS,OPEN_LINKS,$loginDetails){

        $rootScope.activePath = '/';
        $rootScope.$on('$routeChangeStart',function(event,next,current){
          /**
           * Fetching userInfo From local storage here if userInfo is not found in $rootScope
           */
          if(!$rootScope.loginDetails){
            $rootScope.loginDetails = $loginDetails;
          }

          var requestedRoute = '';

          try{
            requestedRoute = next.$$route.originalPath
          }
          catch(ex){
            /**
             * In case if user has opened up the site index he will not be having any requestedRoute
             * then in that case let him navigate
             */
            return;
          }

          /**
           * Checking requestedRoute presence in our configured route lists
           */

          if(OPEN_LINKS.indexOf(requestedRoute) !== -1){
            /**
             * If route is Open then let him navigate it
             */
            return;
          }

          else if(SECURE_LINKS.indexOf(requestedRoute) !== -1){
            /**
             * If user is authenticated let him navigate
             */
            if($rootScope.loginDetails){
              return;
            }
            /**
             * If user is not logged in then redirect him to home page
             */
            else{
              $rootScope.loginDetails = null;
              $location.path('/login');
            }
          }

          else if(INSECURE_LINKS.indexOf(requestedRoute) !== -1){
            /**
             * If user is authenticated don't let him navigate to this route
             */
            if($rootScope.loginDetails){
              $location.path('/');
            }
            /**
             * If user is not logged in then only let him navigate to this page
             */
            else{
              return;
            }
          }
          /**
           * The route which is not added anywhere is considered as publicly open route
           * and let him navigate to it without checking whether he is logged in or not
           */
          else{
            return;
          }
        });

        $rootScope.$on('$routeChangeSuccess',function(event,current){
          $rootScope.activePath = $location.path();
          //console.log($rootScope.activePath);
        });

      $rootScope.$on("$stateChangeStart",
        function(event, toState, toParams, fromState, fromParams) {
          console.log('toState',toState);
          /**
           * If user is not logged in send him to login(landing) page
           */
          if (toState.authState && toState.authenticate && !Authentication.getUserInfo()) {
            $state.go("login");
            event.preventDefault();
          }

          /**
           * If user is logged in and try to go to the URL which is secured
           */
          else if(toState.authState && toState.authenticate && Authentication.getUserInfo()){

            /**
             * Check if user is having permission to go to that state and if he don't have permission then redirect him to respective home url based on his userType
             */
            if(toState.allowedUserTypes && toState.allowedUserTypes.indexOf(Authentication.getUserInfo().userType) == -1){
              switch (Authentication.getUserInfo().userType){
                case 1:
                  $state.go("home");
                  break;
                case 2:
                  $state.go("customer.home");
                  break;
                case 3:
                  $state.go("operator.home");
                  break;
                default:
                  $state.go("home");
              }
              event.preventDefault();
            }
            /**
             * Check if user is having permission to go to that state then don't stop him let him access the URL
             */
            else{

            }

          }

          else if(toState.authState && (!toState.authenticate) && Authentication.getUserInfo()){

            switch (Authentication.getUserInfo().userType){
              case 1:
                $state.go("home");
                break;
              case 2:
                $state.go("customer.home");
                break;
              case 3:
                $state.go("operator.home");
                break;
              default:
                $state.go("home");
            }
            event.preventDefault();
          }
        });

      /**
       * Set current state in $rootScope after stateChange event has successfully took place
       */
      $rootScope.$on("$stateChangeSuccess",function(event, toState, toParams, fromState, fromParams){
        $rootScope.currentState = toState;
        // $rootScope.currentState.name is the actual state name
      });



    }]);
})();





