'use strict';

/**
 * @ngdoc function
 * @name icuttApp.controller:ContactUsCtrl
 * @description
 * # ContactUsCtrl
 * Controller of the icuttApp
 */
angular.module('icuttApp')
  .controller('ContactUsCtrl', ['$rootScope','$scope','$api','$loginDetails','$location',
    function ($rootScope,$scope,$api,$loginDetails,$location) {

    }]);
