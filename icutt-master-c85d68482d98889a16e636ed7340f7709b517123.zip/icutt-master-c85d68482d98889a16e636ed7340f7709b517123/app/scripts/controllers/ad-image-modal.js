'use strict';

/**
 * @ngdoc function
 * @name icuttApp.controller:AdImageModal
 * @description
 * # AdImageModal
 * Controller of the icuttApp
 */

angular.module('icuttApp').controller('AdImageModal', ['$scope','$timeout','$q','$api','ngToast','$modalInstance','domain','ad',
  function ($scope,$timeout,$q,$api,ngToast, $modalInstance,domain,ad) {

    $scope.uploadProgress = false;
    $scope.saveBtnActive = false;



    /**
     * Uploads advertisement images to server
     * @function
     * @return promise
     */
    $scope.uploadImage = function(){
      var defer = $q.defer();

      var imageList = $('#file-input-field')[0].files;

      var requestedData = new FormData();

      for(var i = 0; i < imageList.length; i++){
        requestedData.append('image['+i+']',imageList[i]);
      }
      $scope.uploadProgress = true;
      $api.post(
        '/domain/'+domain+'/ad/'+ad+'/image',
        null,
        requestedData,
        {'Content-Type': undefined },
        angular.identity
      ).then(function(resp){
          $scope.uploadProgress = false;
          if(resp){
            if(resp.status){
              $modalInstance.close(true);
            }
            else{
              defer.reject();
            }
          }
          else{
            defer.reject();
          }
        },function(){
          $scope.uploadProgress = false;
          defer.reject();
        });
      return defer.promise;
    };

    $scope.imageUploadChange = function(){
      var imageList = $('#file-input-field')[0].files;
      console.log(imageList);
      if(imageList){
        console.log(imageList);
        if(imageList.length){
          $scope.saveBtnActive = true;
        }
        else{
          $scope.saveBtnActive = false;
        }
      }
      else{
        $scope.saveBtnActive = false;
      }
      $timeout(function(){
        $scope.$apply();
      },500);
    };

    $scope.ok = function () {
      $scope.uploadImage();
    };

    $scope.cancel = function () {
      $modalInstance.dismiss('cancel');
    };

  }]);
