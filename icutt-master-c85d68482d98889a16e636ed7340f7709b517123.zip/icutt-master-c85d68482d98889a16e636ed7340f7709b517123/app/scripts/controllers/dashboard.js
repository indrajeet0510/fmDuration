'use strict';

/**
 * @ngdoc function
 * @name icuttApp.controller:DashboardCtrl
 * @description
 * # MainCtrl
 * Controller of the icuttApp
 */
angular.module('icuttApp')
  .controller('DashboardCtrl', [  '$scope','$routeParams', '$api','ngToast', function ($scope,$routeParams,$api,ngToast) {
    $scope.domainCount = 0;
    $scope.urlCount = 0;
    $scope.urlViews = 0;
    $scope.quota = 0;

    $scope.accessHistory = [];

    $scope.recentUrlList = [];

    $scope.loadDashBoard = function(){
      return $api.get('/info/dashboard',null,null);
    };

    $scope.loadDashBoard().then(function(resp){
      if(resp){
        if(resp.status && resp.data){
          $scope.domainCount = (resp.data.domains) ? resp.data.domains : 0;
          $scope.urlCount = (resp.data.urls) ? resp.data.urls : 0;
          $scope.urlViews = (resp.data.views) ? resp.data.views : 0;
          $scope.quota = (resp.data.quota) ? resp.data.quota : 0;

          $scope.accessHistory = (resp.data.access_history) ? resp.data.access_history : [];
          $scope.recentUrlList = (resp.data.recent_urls) ? resp.data.recent_urls : [];
        }
      }
    });


  }]);
