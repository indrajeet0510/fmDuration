'use strict';

/**
 * @ngdoc function
 * @name iCuttFrontApp.controller:ApplicationRootCtrl
 * @description
 * # ApplicationRootCtrl
 * Controller of the iCuttFrontApp
 */
angular.module('iCuttFrontApp')
  .controller('ApplicationRootCtrl', function ($scope,$state,$mdSidenav,$timeout,Authentication) {

    $scope.toggleLeft = buildToggler('left');
    $scope.toggleRight = buildToggler('right');

    $scope.navigate = function(state,entityId){
      if(entityId){
        $state.go(state,{entityId : entityId});
      }
      else{
        $state.go(state);
      }
    };

    $scope.languageList = [
      {
        id : 1,
        title : 'English'
      },
      {
        id : 2,
        title : 'Arabic'
      }
    ];

    /**
     * @TODO
     * Introduce language from service injection
     */
    $scope.selectedLanguage = $scope.languageList[0];

    $scope.selectLanguage = function(index){
      $scope.selectedLanguage = $scope.languageList[index];
    };

    function buildToggler(componentId) {
      return function() {
        $mdSidenav(componentId).toggle();
      }
    }
    $scope.userDetails = Authentication.getUserInfo();
    $scope.cLoginUserDetails = (Authentication.getUserInfo())? Authentication.getUserInfo().loginResult : null;

    $scope.$on('loginEvent',function(){
      $timeout(function(){
        console.log(Authentication.getUserInfo());
        $scope.userDetails = Authentication.getUserInfo();
      });

    });

    $scope.logout = function(){
      Authentication.logout().then(function(){
        $scope.userDetails = null;
        $state.go('login');
      },function(){

      });
    };

  });

