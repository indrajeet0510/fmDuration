'use strict';

/**
 * @ngdoc function
 * @name icuttApp.controller:ProfileDomainDetailAdCreateModalCtrl
 * @description
 * # ProfileDomainDetailAdCreateModalCtrl
 * Controller of the icuttApp
 */

angular.module('icuttApp').controller('ProfileDomainDetailAdCreateModalCtrl', ['$scope','$api','ngToast','$modalInstance','domain',
  function ($scope,$api,ngToast, $modalInstance,domain) {

    /**
     * Validation Flag
     * @type {boolean}
     */
    var vFlag  = true;

    var today = new Date();
    $scope.adCampaignTitle = "";
    $scope.endDate = moment().add(15,'day').toDate();
    $scope.error = {
      startDate : false,
      expiryDate : false,
      adCampaignTitle : false
    };


    $scope.minDate = new Date();

    $scope.dateFormat = "dd-MMM-yyyy";
    $scope.startDateStatus = false;
    $scope.dateOptions = {};
    $scope.today = function() {
      $scope.startDate = new Date();
    };
    $scope.today();

    /**
     * Disables weekend section
     */
    $scope.disabled = function(date, mode) {
      return ( mode === 'day' && ( date.getDay() === 0 || date.getDay() === 6 ) );
    };
    /**
     * Opens Date box
     * @param $event
     */
    $scope.openDateBox = function($event,controlIndex) {
      switch(controlIndex){
        case 1 :
              $scope.startDateStatus = true;
              break;
        case 2 :
              $scope.endDateStatus = true;
              break;
        default:
              break;
      }

    };

    $scope.$watch('startDate',function(n,o){
      var mx = moment(n);
      if(n){

          if(mx.isValid()){
            $scope.error.startDate= false;
            if(mx.isAfter($scope.endDate) || n){
              $scope.endDate = moment(n).add(1,'day').toDate();
            }
          }
          else{
            $scope.error.startDate = true;
          }

      }
      else{
        if(!n){
          $scope.error.startDate = true;
        }
      }
    });

    $scope.$watch('endDate',function(n,o){
      var mx = moment(n);
      if(n){

          if(mx.isValid()){
            $scope.error.expiryDate = false;
          }
          else{
            $scope.error.expiryDate = true;
          }
      }
      else{
        if(!n){
          $scope.error.expiryDate = true;
        }
      }
    });



    $scope.ok = function () {
      vFlag = true;
      if(!$scope.adCampaignTitle) {
        $scope.error.adCampaignTitle = true;
        vFlag *= false;
      }
      if(!$scope.startDate){
        $scope.error.startDate = true;
        vFlag *= false;
      }
      if(!$scope.endDate){
        $scope.error.expiryDate = true;
        vFlag *= false;
      }
      if(vFlag){
        $scope.createAdCampaign();
      }
    };

    /**
     * Creates a new ad campaign
     */
    $scope.createAdCampaign = function(){
      $api.post('/domain/'+domain+'/ad',null,{
        domain : domain,
        adCampaignTitle : $scope.adCampaignTitle,
        startDate : moment($scope.startDate).format('YYYY-MM-DD HH:mm:ss'),
        expiryDate : moment($scope.endDate).format('YYYY-MM-DD HH:mm:ss')
      }).then(function(resp){
        if(resp){
          if(resp.status){
            ngToast.success('Ad campaign created successfully');
            $modalInstance.close(resp.data);
          }
          else{
            $scope.error.adCampaignTitle = resp.error.adCampaignTitle;
            $scope.error.domain = resp.error.domain;
            $scope.error.startDate = resp.error.expiryDate;
            $scope.error.expiryDate = resp.error.expiryDate;
            ngToast.danger('An error occurred ! Please check the errors below');
          }
        }
        else{
          ngToast.danger('An error occurred ! Please check the errors below');
        }
      },function(){

      });
    };

    $scope.cancel = function () {
      $modalInstance.dismiss('cancel');
    };
  }]);
