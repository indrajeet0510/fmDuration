'use strict';

/**
 * @ngdoc function
 * @name icuttApp.controller:AdvertisementCtrl
 * @description
 * # MainCtrl
 * Controller of the icuttApp
 */
angular.module('icuttApp')
  .controller('AdvertisementCtrl', ['$rootScope',
    '$scope','$api','$routeParams','$timeout','$window','$location','CONSTANTS','$interval',
    function ($rootScope,$scope,$api,$routeParams,$timeout,$window,$location,CONST,$interval) {

      var random = Math.floor((Math.random() * 10) + 1);
      var timeoutRef = null;
      $scope.adImage = CONST.ADS[random];
      $scope.redirectUrl = '';
      $scope.timeRemaining = 10000;

      $scope.adUrl = CONST.ADS_URL[random];

      angular.element('.advertisement-image').css({'background-image':'url("'+$scope.adImage+'")'});
      /**
       * Loading the short link information and then redirecting user to particular location if link is found
       * else send him page not found 404 view
       */
      if($routeParams['link']){
        $api.get('/url/'+$routeParams['link']).then(function(data){
          if(data){
            if(data.status){
              /**
               * @todo
               * Navigate to original link url according to ad campaign timing
               * Currently hardcoded as 10 seconds to navigate
               */
              $window.redirectUrl = data.data.url;
              $interval(function(){
                if($scope.timeRemaining > 0){
                  $scope.timeRemaining -= 1000;
                }
              },1000);

             timeoutRef = $timeout(function(){
                $window.location.href = data.data.url;
              },10000);
            }
            else{
              $location.path('/404.html');
            }
            console.log(data);
          }
        });
      }



      $api.get('/info/advertisement').then(function(data){
        if(data){
          if(data.status){
            $scope.adImage =   CONST.STATIC_AD_URL + ''+ data.data;
            angular.element('.advertisement-image').css({'background-image':'url("'+$scope.adImage+'")'});
          }
        }
        else{

        }
        console.log(data);
      });



      $scope.$on('$destroy',function(){
        if(timeoutRef){
          $timeout.cancel(timeoutRef);
        }
      });

  }]);
