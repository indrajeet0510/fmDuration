'use strict';

/**
 * @ngdoc function
 * @name icuttApp.controller:ProfileDomainAdDetailCtrl
 * @description
 * # ProfileDomainAdDetailCtrl
 * Controller of the icuttApp
 */
(function(){
  angular.module('icuttApp')
    .controller('ProfileDomainAdDetailCtrl', ['CONSTANTS','$rootScope','$scope','$api','$loginDetails',
      '$location','ngToast','$routeParams','$q','$modal',
      function (CONSTANTS,$rootScope,$scope,$api,$loginDetails,$location,ngToast,$routeParams,$q,$modal) {

        $scope.staticAdUrl = CONSTANTS.STATIC_AD_URL;
        $scope.adCampaign = {};
        $scope.domain = {};

        $scope.pageNumber = 1;
        $scope.totalPages = 1;
        $scope.start = 0;
        $scope.limit = 10;
        $scope.total = 0;
        $scope.imageList = [];


        /**
         * Loads the adcampaign information
         * @returns {*}
         */
        $scope.loadAdCampaign = function(){
          var defer = $q.defer();
          $api.get('/domain/'+$routeParams['id']+'/ad/'+$routeParams['ad_id']).then(function(resp){
            if(resp.status){
              $scope.adCampaign = resp.data;
              if($scope.adCampaign.status){
                $scope.enabled = true;
              }
              defer.resolve();
            }
            else{
              defer.reject();
            }
          },function(){
            defer.reject();
          });
          return defer.promise;
        };

        /**
         * Loads the domain information
         * @returns {*}
         */
        $scope.loadDomain = function(){
          var defer = $q.defer();
          $api.get('/domain/'+$routeParams['id']).then(function(resp){
            if(resp.status){
              $scope.domain = resp.data;
              if($scope.domain.status){
                $scope.enabled = true;
              }
              defer.resolve();
            }
            else{
              defer.reject();
            }
          },function(){
            defer.reject();
          });
          return defer.promise;
        };




        /**
         * Open Ad campaign create modal box
         * @param size
         */
        $scope.openModal = function (size) {
          var modalInstance = $modal.open({
            animation: true,
            templateUrl: 'views/ad-image-modal.html',
            controller: 'AdImageModal',
            size: '',
            resolve: {
              domain : function(){
                return $routeParams['id'];
              },
              ad : function(){
                return $routeParams['ad_id'];
              }
            }
          });

          modalInstance.result.then(function (imageUploadSuccess) {
            if(imageUploadSuccess){
              ngToast.create({
                class : 'success',
                content : '<strong>Success</strong></br>Advertisement Images uploaded successfully'
              });
              $scope.loadImages();
            }
            else{
              ngToast.create({
                class : 'danger',
                content : '<strong>Error</strong></br>Error while uploading ad images'
              });
            }
          }, function () {
            //$log.info('Modal dismissed at: ' + new Date());
          });
        };


        $scope.loadImages = function(){
          var defer = $q.defer();

          $api.get('/domain/'+$routeParams['id']+'/ad/'+$routeParams['ad_id']+'/image',{
            start : $scope.start,
            limit : $scope.limit
            }).then(function(resp){
              if(resp.status){
                $scope.imageList = resp.data;
                $scope.total = resp.total;
                if(resp.total % $scope.limit){
                  $scope.totalPages = parseInt(resp.total/$scope.limit) + 1;
                }
                else{
                  $scope.totalPages = parseInt(resp.total/$scope.limit);
                }

                defer.resolve(resp.data);
              }
              else{
                defer.reject();
              }
            },function(){
                defer.reject();
            });
          return defer.promise;
        };



        $scope.changePageNumber = function(number){
          console.log(number);
          $scope.start = ((number * $scope.limit)+ 1) - $scope.limit ;
          $scope.loadImages().then(function(){
            $scope.pageNumber = number;
          });
        };



        $scope.loadDomain().then(function(){
          $scope.loadAdCampaign().then(function(){
            $scope.loadImages();
          });
        },function(){});




      }]);
})();
