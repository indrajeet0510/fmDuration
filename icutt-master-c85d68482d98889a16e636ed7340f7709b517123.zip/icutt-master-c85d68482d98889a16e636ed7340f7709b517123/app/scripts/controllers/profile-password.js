'use strict';

/**
 * @ngdoc function
 * @name icuttApp.controller:ProfilePasswordCtrl
 * @description
 * # ProfilePasswordCtrl
 * Controller of the icuttApp
 */
angular.module('icuttApp')
  .controller('ProfilePasswordCtrl', ['$rootScope','$scope','$api','$loginDetails','$location','ngToast','$timeout',
    function ($rootScope,$scope,$api,$loginDetails,$location,ngToast,$timeout) {

      $scope.passwordUpdateProgress = false;
      $scope.currentPassword = "";
      $scope.newPassword = "";
      $scope.renewPassword = "";

      $scope.reset = function(){
        $scope.currentPassword = "";
        $scope.newPassword = "";
        $scope.renewPassword = "";
      };

      $scope.changePassword = function(){
        ngToast.dismiss();
        if(!($scope.currentPassword && $scope.newPassword && $scope.renewPassword)){
          ngToast.create({
            className: 'warning',
            content: 'Please fill all the fields'
          });
          return;
        }

        if($scope.newPassword !== $scope.renewPassword)
        {
          ngToast.create({
            className: 'warning',
            content: "Password didn't matched"
          });
          return;
        }

        $scope.passwordUpdateProgress = true;
        $api.post('/user/change_password',null,{
          password : $scope.currentPassword,
          new_password : $scope.newPassword
        }).then(function(resp){
          $scope.passwordUpdateProgress = false;
          if(resp){
            if(resp.status){
              ngToast.create({
                className: 'success',
                content: "Password Changed successfully"
              });
              $scope.reset();
            }
            else{
              if(resp.error){
                var htmlString = '';
                for(var prop in resp.error){
                  if(resp.error.hasOwnProperty(prop)){
                    htmlString += (resp.error[prop] + '<br/>');
                  }
                }
              }
              ngToast.create({
                className: 'danger',
                content: "<strong>Error </strong><br/>"+ htmlString
              });
            }
          }
          else{
            ngToast.create({
              className: 'danger',
              content: 'An error occurred!'
            });
          }

        },function(err){
          $scope.passwordUpdateProgress = false;
          ngToast.create({
            className: 'danger',
            content: 'An error occurred!'
          });
        });

      };

      $timeout(function(){
        angular.element('#oldPassword').focus();
      },1000);

    }]);
