'use strict';

/**
 * @ngdoc function
 * @name icuttApp.controller:LogoutCtrl
 * @description
 * # LogoutCtrl
 * Controller of the icuttApp
 */
(function(){
  angular.module('icuttApp')
    .controller('LogoutCtrl', ['$rootScope','$scope','$api','$loginDetails','$location','ngToast',
      function ($rootScope,$scope,$api,$loginDetails,$location,ngToast) {
        $scope.logout = function(){
          $api.delete('/auth').then(function(data){
            console.log(data);
            if(data){
              if(data.status){
                $rootScope.loginDetails = null;
                ngToast.info('Logged out successfully');
                localStorage.removeItem('_loginDetails');
              }
              else{
                $rootScope.loginDetails = null;
                localStorage.removeItem('_loginDetails');
              }
            }
            else{
              $rootScope.loginDetails = null;
              localStorage.removeItem('_loginDetails');
            }
          });
        };

        //$scope.logout();
      }]);
})();
