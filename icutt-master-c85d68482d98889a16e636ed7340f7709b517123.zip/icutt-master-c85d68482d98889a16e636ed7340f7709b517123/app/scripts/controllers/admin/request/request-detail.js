'use strict';

/**
 * @ngdoc function
 * @name icuttApp.controller:AdminRequestDetailCtrl
 * @description
 * # AdminRequestDetailCtrl
 * Controller of the icuttApp
 */
(function() {
  angular.module('icuttApp')
    .controller('AdminRequestDetailCtrl', ['$rootScope', '$scope', '$api', '$loginDetails', '$location', 'ngToast', '$q', '$modal',
      function ($rootScope, $scope, $api, $loginDetails, $location, ngToast, $q, $modal) {



      }]);
})();
