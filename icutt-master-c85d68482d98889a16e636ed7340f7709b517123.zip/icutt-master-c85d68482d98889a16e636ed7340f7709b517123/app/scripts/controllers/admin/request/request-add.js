'use strict';

/**
 * @ngdoc function
 * @name icuttApp.controller:AdminRequestAddCtrl
 * @description
 * # AdminRequestAddCtrl
 * Controller of the icuttApp
 */
(function() {
  angular.module('icuttApp')
    .controller('AdminRequestAddCtrl', ['$rootScope', '$scope', '$api', '$loginDetails', '$location', 'ngToast', '$q', '$modal',
      function ($rootScope, $scope, $api, $loginDetails, $location, ngToast, $q, $modal) {



      }]);
})();
