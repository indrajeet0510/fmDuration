'use strict';

/**
 * @ngdoc function
 * @name icuttApp.controller:AdminRequestListCtrl
 * @description
 * # AdminRequestListCtrl
 * Controller of the icuttApp
 */
(function() {
  angular.module('icuttApp')
    .controller('AdminRequestListCtrl', ['$rootScope','$timeout' , '$scope', '$api', '$loginDetails', '$location', 'ngToast', '$q', '$modal',
      function ($rootScope, $timeout, $scope, $api, $loginDetails, $location, ngToast, $q, $modal) {

        $scope.requestTypes = [];

        $scope.requestList = [];
        $scope.pageNumber = 1;
        $scope.totalPages = 1;
        $scope.start = 0;
        $scope.limit = 10;
        $scope.total = 0;

        $scope.filter = 0;
        $scope.request = [];
        $scope.searchQuery = '';
        $scope.startDate = moment().subtract(365,'days').toDate();
        $scope.endDate = moment().toDate();

        $scope.loadRequests = function(){

          var reqParams = {
            start : $scope.start,
            limit : $scope.limit
          };

          if(parseInt($scope.filter) !== NaN && parseInt($scope.filter)){
            reqParams.filter = 1;
            reqParams.f_request = $scope.request.join(',');
            reqParams.f_sdate = moment($scope.startDate).format('YYYY-MM-DD');
            reqParams.f_edate = moment($scope.endDate).format('YYYY-MM-DD');
            reqParams.f_query = $scope.searchQuery;
          }

          var defer = $q.defer();
          $api.get('/admin/request',reqParams).then(function(resp){
            if(resp.status){
              $scope.requestList = resp.data;
              $scope.total = resp.total;

              if(resp.total % $scope.limit){
                $scope.totalPages = parseInt(resp.total/$scope.limit) + 1;
              }
              else{
                $scope.totalPages = parseInt(resp.total/$scope.limit);
              }

              defer.resolve();
            }
            else{
              defer.reject();
            }
          },function(){
            defer.reject();
          });
          return defer.promise;
        };

        $scope.changePageNumber = function(number){
          $scope.start = ((number * $scope.limit)+ 1) - $scope.limit ;
          $scope.loadRequests().then(function(){
            $scope.pageNumber = number;
          });
        };

        $scope.loadRequestTypes = function(){
          var defer = $q.defer();
          $api.get('/request/type',null).then(function(resp){
            if(resp.status){
              for(var i =0; i < resp.data.length; i++){
                $scope.requestTypes[resp.data[i].id] = resp.data[i];
              }
              defer.resolve(resp.data);
            }
            else{
              defer.reject();
            }
          },function(){
            defer.reject();
          });
          return defer.promise;
        };

        $timeout(function(){
          $scope.$watch('filter',function(n,o){
            if(n !== o){
              if(!parseInt(n)){
                $scope.loadRequests();
              }
            }
          });
        },5000);


        $scope.openModal = function (index) {
          index = parseInt(index);
          var modalInstance = $modal.open({
            animation: true,
            templateUrl: 'views/admin/domain/domain-edit.html',
            controller: 'AdminDomainEditCtrl',
            size: 'sm',
            resolve: {
              index : index,
              domain : $scope.requestList[index]
            }
          });

          modalInstance.result.then(function (index) {
            $scope.requestList[index].status = 1;
          }, function () {
            //$log.info('Modal dismissed at: ' + new Date());
          });
        };


        /**
         * Date configurations
         */

        $scope.todayDate = moment().format('YYYY-MM-DD');

        $scope.dateFormat = "dd-MMM-yyyy";
        $scope.startDateStatus = false;
        $scope.endDateStatus = false;
        $scope.dateOptions = {};

        $scope.error = {
          startDate : false,
          endDate : false
        };
        /**
         * Disables weekend section
         */
        $scope.disabled = function(date, mode) {
          return ( mode === 'day' && ( date.getDay() === 0 || date.getDay() === 6 ) );
        };
        /**
         * Opens Date box
         * @param $event
         */
        $scope.openDateBox = function($event,controlIndex) {
          switch(controlIndex){
            case 1 :
              $scope.startDateStatus = true;
              break;
            case 2 :
              $scope.endDateStatus = true;
              break;
            default:
              break;
          }

        };



        $scope.$watch('startDate',function(n,o){
          var mx = moment(n);
          if(n){

            if(mx.isValid()){
              $scope.error.startDate= false;
            }
            else{
              $scope.error.startDate = true;
            }

          }
          else{
            if(!n){
              $scope.error.startDate = true;
            }
          }
        });

        $scope.$watch('endDate',function(n,o){
          var mx = moment(n);
          if(n){

            if(mx.isValid()){
              $scope.error.endDate = false;
            }
            else{
              $scope.error.endDate = true;
            }
          }
          else{
            if(!n){
              $scope.error.endDate = true;
            }
          }
        });

        $scope.loadRequestTypes().then(function(){
          $scope.loadRequests();
        },function(){
          $scope.loadRequests();
        });


      }]);
})();
