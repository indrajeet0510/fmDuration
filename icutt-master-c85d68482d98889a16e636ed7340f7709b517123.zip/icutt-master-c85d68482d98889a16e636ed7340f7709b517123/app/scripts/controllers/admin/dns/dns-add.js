'use strict';

/**
 * @ngdoc function
 * @name icuttApp.controller:AdminDnsAddCtrl
 * @description
 * # AdminDnsAddCtrl
 * Controller of the icuttApp
 */

angular.module('icuttApp').controller('AdminDnsAddCtrl', ['$scope','$timeout','$api','ngToast','$q','$modalInstance',
  function ($scope,$timeout,$api,ngToast,$q, $modalInstance) {

    $scope.newDns = '';
    $scope.error = {};
    $scope.dnsAddProcess = false;

    $scope.addDns = function(){

      var defer = $q.defer();
      if(validator.isFQDN($scope.newDns)){
        $scope.dnsAddProcess = true;
        $api.post('/admin/dns',null,{
          dns : $scope.newDns
        }).then(function(resp){
          $scope.dnsAddProcess = false;
          if(resp){
            if(resp.status){
              ngToast.success('DNS created successfully');
              defer.resolve(resp.data);
            }
            else{
              $scope.error.dns = resp.error.dns;
              ngToast.danger('An error occurred ! Please check the errors below');
              defer.reject();
            }
          }
          else{
            ngToast.danger('An error occurred ! Please check the errors below');
            defer.reject();
          }
        },function(){
          $scope.dnsAddProcess = false;
          ngToast.danger('An error occurred ! Please check the errors below');
          defer.reject();

        });
      }
      else{
        $scope.error.dns = 'Please enter a valid Fully Qualified Domain Name eg. ns1.example.com';
        defer.reject();
      }

      return defer.promise;
    };

    $scope.ok = function () {
      $scope.addDns().then(function(newDns){
        $modalInstance.close(newDns);
      },function(){
      });
    };

    $scope.cancel = function () {
      $modalInstance.dismiss('cancel');
    };

    $timeout(function(){
      angular.element('#input-dns').focus();
    },500);

  }]);
