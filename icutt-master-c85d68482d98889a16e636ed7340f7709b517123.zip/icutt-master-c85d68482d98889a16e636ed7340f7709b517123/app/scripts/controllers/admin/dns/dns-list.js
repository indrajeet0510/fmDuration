'use strict';

/**
 * @ngdoc function
 * @name icuttApp.controller:AdminDnsListCtrl
 * @description
 * # AdminDnsListCtrl
 * Controller of the icuttApp
 */
(function(){
  angular.module('icuttApp')
    .controller('AdminDnsListCtrl', ['$rootScope','$scope','$api','$loginDetails','$location','ngToast','$q','$modal',
      function ($rootScope,$scope,$api,$loginDetails,$location,ngToast,$q,$modal) {

        $scope.dnsList = [];
        $scope.pageNumber = 1;
        $scope.totalPages = 1;
        $scope.start = 0;
        $scope.limit = 10;
        $scope.total = 0;

        $scope.loadDns = function(){
          var defer = $q.defer();
          $api.get('/admin/dns',{
            start : $scope.start,
            limit : $scope.limit
          }).then(function(resp){
            if(resp.status){
              $scope.dnsList = resp.data;
              $scope.total = resp.total;

              if(resp.total % $scope.limit){
                $scope.totalPages = parseInt(resp.total/$scope.limit) + 1;
              }
              else{
                $scope.totalPages = parseInt(resp.total/$scope.limit);
              }

              defer.resolve();
            }
            else{
              defer.reject();
            }
          },function(){
            defer.reject();
          });
          return defer.promise;
        };

        $scope.changePageNumber = function(number){
          $scope.start = ((number * $scope.limit)+ 1) - $scope.limit ;
          $scope.loadDns().then(function(){
            $scope.pageNumber = number;
          });
        };



        $scope.openAddModal = function (size) {
          var modalInstance = $modal.open({
            animation: true,
            templateUrl: 'views/admin/dns/dns-add.html',
            controller: 'AdminDnsAddCtrl',
            size: 'sm',
            resolve: {

            }
          });

          modalInstance.result.then(function (newDns) {
            $scope.total += 1;
            if($scope.dnsList.length === 10){
              $scope.dnsList.pop();
            }
            $scope.dnsList.unshift(newDns);
          }, function () {
            //$log.info('Modal dismissed at: ' + new Date());
          });
        };


        $scope.deleteDns = function(index){

          var delmodalInstance = $modal.open({
            animation: true,
            templateUrl: 'views/admin/dns/dns-delete.html',
            controller: 'AdminDnsDeleteCtrl',
            size: 'sm',
            resolve: {

            }
          });

          delmodalInstance.result.then(function(confirmation) {
            if(confirmation){
              var id = $scope.dnsList[index].id;
              $api.delete('/admin/dns/'+id,null).then(function(resp){
                if(resp){
                  if(resp.status){
                    ngToast.success('DNS record removed successfully');
                    $scope.dnsList.splice(index,1);
                    $scope.total -= 1;
                  }
                  else{
                    ngToast.error('An error occurred ! Please check the errors below');
                  }
                }
                else{
                  ngToast.error('An error occurred ! Please check the errors below');
                }
              });
            }
          },function(){
            console.log('Not deleted');
          });

        };

        $scope.loadDns();


      }]);
})();
