'use strict';

/**
 * @ngdoc function
 * @name icuttApp.controller:AdminDomainListCtrl
 * @description
 * # AdminDomainListCtrl
 * Controller of the icuttApp
 */
(function() {
  angular.module('icuttApp')
    .controller('AdminDomainListCtrl', ['$rootScope', '$scope', '$api', '$loginDetails', '$location', 'ngToast', '$q', '$modal',
      function ($rootScope, $scope, $api, $loginDetails, $location, ngToast, $q, $modal) {

        $scope.requestTypes = [];

        $scope.domainList = [];
        $scope.pageNumber = 1;
        $scope.totalPages = 1;
        $scope.start = 0;
        $scope.limit = 10;
        $scope.total = 0;

        $scope.filter = 0;
        $scope.status = '0';
        $scope.searchQuery = '';
        $scope.startDate = moment().subtract(365,'days').toDate();
        $scope.endDate = moment().toDate();

        $scope.loadDomains = function(){

          var reqParams = {
            start : $scope.start,
            limit : $scope.limit
          };

          if(parseInt($scope.filter) !== NaN && parseInt($scope.filter)){
            reqParams.filter = 1;
            reqParams.f_status = $scope.status;
            reqParams.f_sdate = moment($scope.startDate).format('YYYY-MM-DD');
            reqParams.f_edate = moment($scope.endDate).format('YYYY-MM-DD');
            reqParams.f_query = $scope.searchQuery;
          }

          var defer = $q.defer();
          $api.get('/admin/domain',reqParams).then(function(resp){
            if(resp.status){
              $scope.domainList = resp.data;
              $scope.total = resp.total;

              if(resp.total % $scope.limit){
                $scope.totalPages = parseInt(resp.total/$scope.limit) + 1;
              }
              else{
                $scope.totalPages = parseInt(resp.total/$scope.limit);
              }

              defer.resolve();
            }
            else{
              defer.reject();
            }
          },function(){
            defer.reject();
          });
          return defer.promise;
        };

        $scope.changePageNumber = function(number){
          $scope.start = ((number * $scope.limit)+ 1) - $scope.limit ;
          $scope.loadDomains().then(function(){
            $scope.pageNumber = number;
          });
        };

        $scope.$watch('filter',function(n,o){
          if(!parseInt(n)){
            $scope.loadDomains();
          }
        });


        $scope.openModal = function (index) {
          index = parseInt(index);
          console.log(index);
          var modalInstance = $modal.open({
            animation: true,
            templateUrl: 'views/admin/domain/domain-edit.html',
            controller: 'AdminDomainEditCtrl',
            size: 'sm',
            resolve: {
              domainToEdit : function(){
                return $scope.domainList[index]
              },
              domainIndex : function(){
                return index;
              }
            }
          });

          modalInstance.result.then(function (index,status) {
            //$scope.domainList[index].status = status;
            $scope.domainList[index].updated_on = moment().format('MMM DD, YYYY HH:mm');
          }, function () {
            //$log.info('Modal dismissed at: ' + new Date());
          });
        };

        $scope.editDomain = function(index){
          $scope.openModal(index);
        };


        /**
         * Date configurations
         */

        $scope.todayDate = moment().format('YYYY-MM-DD');

        $scope.dateFormat = "dd-MMM-yyyy";
        $scope.startDateStatus = false;
        $scope.endDateStatus = false;
        $scope.dateOptions = {};

        $scope.error = {
          startDate : false,
          endDate : false
        };
        /**
         * Disables weekend section
         */
        $scope.disabled = function(date, mode) {
          return ( mode === 'day' && ( date.getDay() === 0 || date.getDay() === 6 ) );
        };
        /**
         * Opens Date box
         * @param $event
         */
        $scope.openDateBox = function($event,controlIndex) {
          switch(controlIndex){
            case 1 :
              $scope.startDateStatus = true;
              break;
            case 2 :
              $scope.endDateStatus = true;
              break;
            default:
              break;
          }

        };



        $scope.$watch('startDate',function(n,o){
          var mx = moment(n);
          if(n){

            if(mx.isValid()){
              $scope.error.startDate= false;
            }
            else{
              $scope.error.startDate = true;
            }

          }
          else{
            if(!n){
              $scope.error.startDate = true;
            }
          }
        });

        $scope.$watch('endDate',function(n,o){
          var mx = moment(n);
          if(n){

            if(mx.isValid()){
              $scope.error.endDate = false;
            }
            else{
              $scope.error.endDate = true;
            }
          }
          else{
            if(!n){
              $scope.error.endDate = true;
            }
          }
        });

        $scope.loadDomains();



      }]);
})();
