'use strict';

/**
 * @ngdoc function
 * @name icuttApp.controller:AdminDomainEditCtrl
 * @description
 * # AdminDomainEditCtrl
 * Controller of the icuttApp
 */

angular.module('icuttApp').controller('AdminDomainEditCtrl',
  ['$scope','$api','$q','ngToast','$modalInstance','domainToEdit','domainIndex',
  function ($scope,$api, $q, ngToast, $modalInstance,domainToEdit,domainIndex) {

    console.log(domainToEdit);

    $scope.error = {};
    $scope.domainEditProcess = false;

    $scope.domainToEdit = domainToEdit;

    $scope.editDomain = function(){
      var defer = $q.defer();
      $scope.domainEditProcess = true;
      var dE = domainToEdit;
      dE.status = (dE.status) ? 0 : 1;
      $api.put('/admin/domain/'+domainToEdit.id,null,dE).then(function(resp){
        $scope.domainEditProcess = false;
        if(resp){
          if(resp.status){
            var message = 'Domain deactivated successfully';
            if(domainToEdit.status == 1){
              message = 'Domain activated successfully';
            }
            ngToast.success(message);
            defer.resolve(domainToEdit.status);
          }
          else{
            $scope.error.domain = resp.error.domain;
            ngToast.danger('An error occurred ! Please check the errors below');
            defer.reject();
          }
        }
        else{
          ngToast.danger('An error occurred ! Please check the errors below');
          defer.reject();
        }
      },function(){
        $scope.domainEditProcess = false;
        ngToast.danger('An error occurred ! Please check the errors below');
        defer.reject();

      });
      return defer.promise;
    };


    $scope.ok = function () {
      $scope.editDomain().then(function(st){
        console.log(domainIndex);
        $modalInstance.close(domainIndex,st);
      },function(){
      });
    };

    $scope.cancel = function () {
      $modalInstance.dismiss('cancel');
    };

  }]);
