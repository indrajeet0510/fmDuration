'use strict';

/**
 * @ngdoc function
 * @name icuttApp.controller:ProfileSubscriptionCtrl
 * @description
 * # ProfileSubscriptionCtrl
 * Controller of the icuttApp
 */
angular.module('icuttApp')
  .controller('ProfileSubscriptionCtrl', ['$rootScope','$scope','$api','$loginDetails','$location',
    function ($rootScope,$scope,$api,$loginDetails,$location) {

    }]);
