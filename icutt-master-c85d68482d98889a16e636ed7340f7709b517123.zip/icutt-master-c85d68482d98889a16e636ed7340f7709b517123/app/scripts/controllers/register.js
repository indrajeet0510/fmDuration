'use strict';

/**
 * @ngdoc function
 * @name icuttApp.controller:RegisterCtrl
 * @description
 * # MainCtrl
 * Controller of the icuttApp
 */
angular.module('icuttApp')
  .controller('RegisterCtrl', [
    '$scope','$api','$routeParams','$timeout','$window','$location','CONSTANTS','$interval','ngToast',
    function ($scope,$api,$routeParams,$timeout,$window,$location,CONST,$interval,ngToast) {

    $scope.fullName = "";
    $scope.sPassword = "";
    $scope.resPassword = "";
    $scope.email = "";

    $scope.reset = function(){
      $scope.fullName = "";
      $scope.sPassword = "";
      $scope.resPassword = "";
      $scope.email = "";
    };

    $scope.registerProgress = false;



    $scope.register = function(){
      $scope.registerProgress = true;
      $api.post('/user',null,{
        full_name : $scope.fullName,
        password : $scope.sPassword,
        repassword : $scope.resPassword,
        email : $scope.email
      }).then(function(resp){
        $scope.registerProgress = false;
        if(resp){
          if(resp.status){
            ngToast.create({
              className : 'success',
              content : '<strong>Success</strong> Your registration is successful ! Please login to continue'
            });
            $scope.reset();
            $scope.signupForm.$setPristine();
          }
          else{
            var htmlStr = '';
            for(var prop in resp.error){
              if(resp.error.hasOwnProperty(prop)){
                htmlStr += resp.error[prop] + '<br/>';
              }
            }
            ngToast.create({
              className : 'danger',
              content : htmlStr
            });
          }
        }
        else{
          ngToast.danger('An error occurred ! Please try again');
        }
      },function(err){
        $scope.registerProgress = false;
        ngToast.danger('An error occurred ! Please try again');
      })
    };


    $timeout(function(){
      angular.element('#full-name').focus();
    },1000);

  }]);
