'use strict';

/**
 * @ngdoc function
 * @name icuttApp.controller:ProfileAdvertisementCtrl
 * @description
 * # ProfileAdvertisementCtrl
 * Controller of the icuttApp
 */
angular.module('icuttApp')
  .controller('ProfileAdvertisementCtrl', [
    '$scope','$api','$routeParams','$timeout','$window','$location',
    function ($scope,$api,$routeParams,$timeout,$window,$location) {

    }
  ]);
