'use strict';

/**
 * @ngdoc function
 * @name icuttApp.controller:LoginCtrl
 * @description
 * # MainCtrl
 * Controller of the icuttApp
 */
angular.module('icuttApp')
  .controller('LoginCtrl', ['$rootScope','$scope','$api','$loginDetails','$location','ngToast','$timeout',
    function ($rootScope,$scope,$api,$loginDetails,$location,ngToast,$timeout) {
      $scope.email = '';
      $scope.password = '';
      $scope.loginProgress = false;

      $scope.triggerLogin = function(e){
        if(e){
          if(e.charCode == 13){
            $scope.login();
          }
        }
      };

      $scope.login = function(){
        $scope.loginProgress = true;
        $api.post('/auth',null,{
          email : $scope.email,
          password : $scope.password
        }).then(function(data){
          $scope.loginProgress = false;
          if(data){
            if(data.status){
              $rootScope.loginDetails = data;
              console.log(data);
              localStorage.setItem('_loginDetails',JSON.stringify(data));
              $location.path('/dashboard');
            }
            else{
              ngToast.create({
                class : 'warning',
                content : '<strong>Invalid Credentials</strong>'
              });
            }
          }
          else{
            ngToast.create({
              class : 'danger',
              content : '<strong>An error occurred</strong>'
            });
          }
        },function(){
          $scope.loginProgress = false;
          ngToast.create({
            class : 'danger',
            content : '<strong>An error occurred</strong>'
          });
        });
      };

      $timeout(function(){
        angular.element('#email').focus();
      },1000);

  }]);
