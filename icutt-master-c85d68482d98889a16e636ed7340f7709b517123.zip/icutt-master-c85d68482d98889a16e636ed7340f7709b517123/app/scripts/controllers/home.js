'use strict';

/**
 * @ngdoc function
 * @name icuttApp.controller:HomeCtrl
 * @description
 * # MainCtrl
 * Controller of the icuttApp
 */
(function(){
  angular.module('icuttApp')
    .controller('HomeCtrl', [ '$scope','$routeParams', '$api','ngToast','APP_DOMAIN','$timeout',
      function ($scope,$routeParams,$api,ngToast,APP_DOMAIN,$timeout) {

      /** Find links from text and return in form of array **/
      var getLinksOld = function(linkStr) {
        var linkRegex = /(https?:\/\/([-\w\.]+)+(:\d+)?(\/([\w\/_\.]*(\?\S+)?)?)?)/ig, result, indices = [];
        while ( (result = linkRegex.exec(linkStr)) ) {
          indices.push(result[0]);
        }
        return indices;
      };



      var getLinks = function(linkStr){
        var indices = [];
        Autolinker.link( linkStr, {
          replaceFn : function( autolinker, match ) {
            //console.log( "href = ", match.getAnchorHref() );
            //console.log( "text = ", match.getAnchorText() );

            switch( match.getType() ) {
              case 'url' :
                console.log( "url: ", match.getUrl() );
                indices.push(match.getUrl());
                return true;  // let Autolinker perform its normal anchor tag replacement
            }
          }
        } );
        return indices;
      };

      $scope.multiUrlBlockVisible = false;
      $scope.singleUrlBlockVisible = true;
      $scope.multiUrlGenerated = false;
      $scope.urlProgress = false;
      $scope.isMasterApp = false;
      if(location.hostname == APP_DOMAIN){
        $scope.isMasterApp = true;
      }

      $scope.isUrlGenerated = false;
      $scope.longUrl = "";
      $scope.longUrlString = "";
      $scope.suffix = "";

      function isUrlValid(url) {
        return /^(https?|s?ftp):\/\/(((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?(\?((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\uE000-\uF8FF]|\/|\?)*)?(#((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?$/i.test(url);
      }

      var checkScheme = function(url){
        if(validator.isURL(url,{require_tld : false,require_protocol : true})){
          return url;
        }
        else{
          if(validator.isURL('http://'+url,{require_tld : false,require_protocol : true})){
            return 'http://'+url;
          }
          else{
            return null;
          }
        }
      };

      $scope.generateShortUrl = function(){
        var url = checkScheme($scope.longUrl);
        var suffixFlag = true;
        if($scope.suffix){
          suffixFlag = validator.isAlphanumeric($scope.suffix);
        }

        if(url && suffixFlag){
          $scope.urlProgress = true;
          $api.post('/url',null,{
            url : url,
            suffix : $scope.suffix
          }).then(function(resp){
            $scope.urlProgress = false;
            if(resp){
              if(resp.status){
                $scope.isUrlGenerated = true;
                $scope.shortUrl = 'http://'+location.host + '/' + ((resp.data.suffix) ?  (resp.data.suffix +'-'+resp.data.shortUrl) : resp.data.shortUrl);
              }
            }
          });
        }
        else if(!suffixFlag){
          $scope.urlProgress = false;
          ngToast.danger('Suffix can only contain letters and numbers');
        }
        else{
          $scope.urlProgress = false;
          ngToast.danger('Invalid URL');
        }
      };

      $scope.resetForm = function(){
        $scope.shortUrl = "";
        $scope.longUrl = "";
        $scope.isUrlGenerated = false;
      };

      $scope.$watch('multiUrlBlockVisible',function(n,o){
          $scope.suffix  = '';
          $scope.longUrlString = '';
      });

      $scope.$watch('singleUrlBlockVisible',function(n,o){
        if(n){
          $scope.suffix  = '';
          $scope.longUrlString = '';
        }
      });

      $scope.viewMultiUrlShortener = function(){
        if($scope.multiUrlBlockVisible){
          $scope.multiUrlBlockVisible = false;
          $scope.singleUrlBlockVisible = true;
          $scope.multiUrlGenerated = false;
        }
        else{
          $scope.singleUrlBlockVisible = false;
          $scope.multiUrlBlockVisible = true;
          $scope.multiUrlGenerated = false;
        }
      };

      $scope.$watch('suffix',function(n,o){
        var regExp = /^[0-9A-Za-z]+$/;

        if(n){

          if(n !== o){
            if(regExp.test(n)){

            }
            else{
              $scope.suffix = o;
            }
          }
        }

      });



      $scope.getMultiShortUrls = function(){
        var linkList = [];
        if($scope.longUrlString){
          linkList = getLinks($scope.longUrlString);
          if(linkList.length){
            var suffixFlag = true;
            if($scope.suffix){
              suffixFlag = validator.isAlphanumeric($scope.suffix);
            }

            if(linkList && suffixFlag){
              $scope.urlProgress = true;
              $api.post('/url/multiple',null,{
                url_list : linkList,
                suffix : $scope.suffix
              }).then(function(resp){
                $scope.urlProgress = false;
                if(resp){
                  if(resp.status){
                    $scope.multiUrlGenerated = true;
                    var urlText = angular.copy($scope.longUrlString);
                    for(var i=0; i < linkList.length; i++){
                      var urlLink = 'http://'+location.host + '/' + ((resp.data[i].suffix) ?  (resp.data[i].suffix +'-'+resp.data[i].shortUrl) : resp.data[i].shortUrl);
                      urlText = urlText.replace(linkList[i], urlLink);
                    }
                    $scope.longUrlString = angular.copy(urlText);
                  }
                }
                else{
                  ngToast.danger('Something went wrong ! Please try again..');
                }
              },function(){
                $scope.urlProgress = false;
                ngToast.danger('Something went wrong ! Please try again..');

              });
            }
            else if(!suffixFlag){
              $scope.urlProgress = false;
              ngToast.danger('Suffix can only contain letters and numbers');
            }
            else{
              $scope.urlProgress = false;
              ngToast.danger('Invalid URL');
            }
          }
        }

      };



      $timeout(function(){
        angular.element('#urlInput').focus();
      },1000);

    }]);
})();
