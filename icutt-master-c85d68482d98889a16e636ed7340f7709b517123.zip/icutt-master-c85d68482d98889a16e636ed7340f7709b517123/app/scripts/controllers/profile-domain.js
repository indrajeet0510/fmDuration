'use strict';

/**
 * @ngdoc function
 * @name icuttApp.controller:ProfileDomainCtrl
 * @description
 * # ProfileDomainCtrl
 * Controller of the icuttApp
 */
angular.module('icuttApp')
  .controller('ProfileDomainCtrl', ['$rootScope','$q','$scope','$api','$loginDetails','$location','ngToast','$modal',
    function ($rootScope,$q,$scope,$api,$loginDetails,$location,ngToast,$modal) {

      $scope.domainList = [];
      $scope.pageNumber = 1;
      $scope.totalPages = 1;
      $scope.start = 0;
      $scope.limit = 10;
      $scope.total = 0;

      $scope.loadDomains = function(){
        var defer = $q.defer();
        $api.get('/domain',{
          start : $scope.start,
          limit : $scope.limit
        }).then(function(resp){
          if(resp.status){
            $scope.domainList = resp.data;
            $scope.total = resp.total;

            if(resp.total % $scope.limit){
              $scope.totalPages = parseInt(resp.total/$scope.limit) + 1;
            }
            else{
              $scope.totalPages = parseInt(resp.total/$scope.limit);
            }

            defer.resolve();
          }
          else{
            defer.reject();
          }
        },function(){
          defer.reject();
        });
        return defer.promise;
      };

      $scope.changePageNumber = function(number){
        $scope.start = ((number * $scope.limit)+ 1) - $scope.limit ;
        $scope.loadDomains().then(function(){
          $scope.pageNumber = number;
        });
      };


      $scope.openModal = function (size) {
        var modalInstance = $modal.open({
          animation: true,
          templateUrl: 'views/profile-domain-modal-edit.html',
          controller: 'ProfileDomainModalEditCtrl',
          size: 'sm',
          resolve: {

          }
        });

        modalInstance.result.then(function (newDomain) {
          $scope.total += 1;
          if($scope.domainList.length === 10){
            $scope.domainList.pop();
          }
          $scope.domainList.unshift(newDomain);
        }, function () {
          //$log.info('Modal dismissed at: ' + new Date());
        });
      };


      $scope.deleteDomain = function(index){

        var delmodalInstance = $modal.open({
          animation: true,
          templateUrl: 'views/profile-domain-modal-delete.html',
          controller: 'ProfileDomainModalDeleteCtrl',
          size: 'sm',
          resolve: {

          }
        });

        delmodalInstance.result.then(function(confirmation) {
          if(confirmation){
            var id = $scope.domainList[index].id;
            $api.delete('/domain/'+id,null).then(function(resp){
              if(resp){
                if(resp.status){
                  ngToast.success('Domain removed successfully');
                  $scope.domainList.splice(index,1);
                  $scope.total -= 1;
                }
                else{
                  ngToast.danger('An error occurred ! Please check the errors below');
                }
              }
              else{
                ngToast.danger('An error occurred ! Please check the errors below');
              }
            });
          }
        },function(){});

      };



      $scope.loadDomains();


    }]);
