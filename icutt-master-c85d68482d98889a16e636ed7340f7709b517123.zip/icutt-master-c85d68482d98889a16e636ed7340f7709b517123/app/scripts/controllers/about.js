'use strict';

/**
 * @ngdoc function
 * @name icuttApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the icuttApp
 */
angular.module('icuttApp')
  .controller('AboutCtrl', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
