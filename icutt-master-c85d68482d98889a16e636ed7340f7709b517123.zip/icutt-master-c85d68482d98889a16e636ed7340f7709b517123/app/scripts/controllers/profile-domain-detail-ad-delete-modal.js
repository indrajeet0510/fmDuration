'use strict';

/**
 * @ngdoc function
 * @name icuttApp.controller:ProfileDomainDetailAdDeleteModal
 * @description
 * # ProfileDomainDetailAdDeleteModal
 * Controller of the icuttApp
 */

angular.module('icuttApp').controller('ProfileDomainDetailAdDeleteModal', ['$scope','$api','ngToast','$modalInstance',
  function ($scope,$api,ngToast, $modalInstance) {

    $scope.ok = function () {
      $modalInstance.close(true);
    };

    $scope.cancel = function () {
      $modalInstance.dismiss('cancel');
    };

  }]);
