'use strict';

/**
 * @ngdoc function
 * @name icuttApp.controller:ProfileCtrl
 * @description
 * # ProfileCtrl
 * Controller of the icuttApp
 */
angular.module('icuttApp')
  .controller('ProfileCtrl', ['$rootScope','$scope','$api','$loginDetails','$location',
    function ($rootScope,$scope,$api,$loginDetails,$location) {

    }]);
