'use strict';

/**
 * @ngdoc function
 * @name icuttApp.controller:ProfileDomainModalEditCtrl
 * @description
 * # ProfileDomainModalEditCtrl
 * Controller of the icuttApp
 */

angular.module('icuttApp').controller('ProfileDomainModalDeleteCtrl', ['$scope','$api','ngToast','$modalInstance',
  function ($scope,$api,ngToast, $modalInstance) {

    $scope.ok = function () {
      $modalInstance.close(true);
    };

    $scope.cancel = function () {
      $modalInstance.dismiss('cancel');
    };

  }]);
