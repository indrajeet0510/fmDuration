'use strict';

/**
 * @ngdoc function
 * @name icuttApp.controller:ProfileDomainAdListCtrl
 * @description
 * # ProfileDomainAdListCtrl
 * Controller of the icuttApp
 */
angular.module('icuttApp')
    .controller('ProfileDomainAdListCtrl', ['$rootScope','$scope','$api','$loginDetails','$location','ngToast','$routeParams','$q','$modal',
      function ($rootScope,$scope,$api,$loginDetails,$location,ngToast,$routeParams,$q,$modal) {

        $scope.domain = {};

        $scope.adCampaignList = [];
        $scope.pageNumber = 1;
        $scope.totalPages = 1;
        $scope.start = 0;
        $scope.limit = 10;
        $scope.total = 0;

        $scope.loadAdCampaigns = function(){
          var defer = $q.defer();
          $api.get('/domain/'+$routeParams['id']+'/ad',{
            start : $scope.start,
            limit : $scope.limit
          }).then(function(resp){
            if(resp.status){
              $scope.adCampaignList = resp.data;
              $scope.total = resp.total;

              if(resp.total % $scope.limit){
                $scope.totalPages = parseInt(resp.total/$scope.limit) + 1;
              }
              else{
                $scope.totalPages = parseInt(resp.total/$scope.limit);
              }

              defer.resolve();
            }
            else{
              defer.reject();
            }
          },function(){
            defer.reject();
          });
          return defer.promise;
        };

        $scope.changePageNumber = function(number){
          $scope.start = ((number * $scope.limit)+ 1) - $scope.limit ;
          $scope.loadAdCampaigns().then(function(){
            $scope.pageNumber = number;
          });
        };


        /**
         * Open Ad campaign create modal box
         * @param size
         */
        $scope.openModal = function (size) {
          var modalInstance = $modal.open({
            animation: true,
            templateUrl: 'views/profile-domain-detail-ad-create-modal.html',
            controller: 'ProfileDomainDetailAdCreateModalCtrl',
            size: '',
            resolve: {
              domain : function(){
                return $routeParams['id'];
              }
            }
          });

          modalInstance.result.then(function (newAdCampaign) {
            $scope.total +=  1;
            if($scope.adCampaignList.length === 10){
              $scope.adCampaignList.pop();
            }
            $scope.adCampaignList.unshift(newAdCampaign);

          }, function () {
            //$log.info('Modal dismissed at: ' + new Date());
          });
        };



        $scope.deleteAdCampaign = function(index){

          var delmodalInstance = $modal.open({
            animation: true,
            templateUrl: 'views/profile-domain-detail-ad-delete-modal.html',
            controller: 'ProfileDomainDetailAdDeleteModal',
            size: 'sm',
            resolve: {

            }
          });

          delmodalInstance.result.then(function(confirmation) {
            if(confirmation){
              var id = $scope.adCampaignList[index].id;
              $api.delete('/domain/'+$routeParams['id']+'/ad/'+id,null).then(function(resp){
                if(resp){
                  if(resp.status){
                    ngToast.success('Campaign removed successfully');
                    $scope.adCampaignList.splice(index,1);
                    $scope.total -= 1;
                  }
                  else{
                    ngToast.error('An error occurred ! Please check the errors below');
                  }
                }
                else{
                  ngToast.error('An error occurred ! Please check the errors below');
                }
              });
            }
          },function(){});

        };


        /**
         * Loads the domain information
         * @returns {*}
         */
        $scope.loadDomain = function(){
          var defer = $q.defer();
          $api.get('/domain/'+$routeParams['id']).then(function(resp){
            if(resp.status){
              $scope.domain = resp.data;
              if($scope.domain.status){
                $scope.enabled = true;
              }
              defer.resolve();
            }
            else{
              defer.reject();
            }
          },function(){
            defer.reject();
          });
          return defer.promise;
        };




        $scope.loadDomain().then(function(){
          $scope.loadAdCampaigns();
        });



      }]);
