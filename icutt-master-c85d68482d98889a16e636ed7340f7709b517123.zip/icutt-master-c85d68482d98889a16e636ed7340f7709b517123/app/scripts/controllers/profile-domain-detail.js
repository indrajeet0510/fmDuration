'use strict';

/**
 * @ngdoc function
 * @name icuttApp.controller:ProfileDomainDetailCtrl
 * @description
 * # ProfileDomainDetailCtrl
 * Controller of the icuttApp
 */
(function(){
  angular.module('icuttApp')
    .controller('ProfileDomainDetailCtrl', ['$rootScope',
      '$scope','$api','$loginDetails',
      '$location','ngToast','$q','$routeParams','$modal',
      function ($rootScope,$scope,$api,$loginDetails,$location,ngToast,$q,$routeParams,$modal) {

        $scope.domain = {};

        /**
         * Model for storing the state of switch button (directive)
         * @type {boolean}
         */
        $scope.enabled = false;

        /**
         * Called upon ng-change of switch button (directive)
         */
        $scope.changeCallback = function(){};

        /**
         * Navigate to list of ad campaigns
         */
        $scope.showAdCampaigns = function(){
          $location.path('/profile/domain/'+$routeParams['id']+'/ad');
        };

        /**
         * Loads the domain information
         * @returns {*}
         */
        $scope.loadDomain = function(){
          var defer = $q.defer();
          $api.get('/domain/'+$routeParams['id']).then(function(resp){
            if(resp.status){
              $scope.domain = resp.data;
              if($scope.domain.status){
                $scope.enabled = true;
              }
              defer.resolve();
            }
            else{
              defer.reject();
            }
          },function(){
            defer.reject();
          });
          return defer.promise;
        };


        /**
         * Open Ad campaign create modal box
         * @param size
         */
        $scope.openModal = function (size) {
          var modalInstance = $modal.open({
            animation: true,
            templateUrl: 'views/profile-domain-detail-ad-create-modal.html',
            controller: 'ProfileDomainDetailAdCreateModalCtrl',
            size: '',
            resolve: {
              domain : function(){
                return $routeParams['id'];
              }
            }
          });

          modalInstance.result.then(function (newAdCampaign) {
            $scope.domain.ad_campaigns = ($scope.domain.ad_campaigns+  1);
          }, function () {
            //$log.info('Modal dismissed at: ' + new Date());
          });
        };


        if(parseInt($routeParams['id']) !== NaN && parseInt($routeParams['id']) > 0){
            $scope.loadDomain().then(function(){
              /**
               * Nothing to do when domain information is loaded successfully
               */
            },function(){
              /**
               * If domain is invalid, then we redirect him to 404 not found page
               */
              $location.path('/404.html');
            });
        }
        else{
          $location.path('/404.html');
        }

      }]);
})();
