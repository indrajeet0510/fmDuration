'use strict';

/**
 * @ngdoc function
 * @name icuttApp.controller:NavigationCtrl
 * @description
 * # NavigationCtrl
 * Controller of the icuttApp
 */
angular.module('icuttApp')
  .controller('NavigationCtrl', ['$scope','$api','API_URL', 'APP_DOMAIN','$rootScope','$location','ngToast','$timeout',
    function ($scope,$api,API_URL,APP_DOMAIN,$rootScope,$location,ngToast,$timeout) {
    $scope.appName = APP_DOMAIN;
    $scope.isMasterApp = true;

    if(location.hostname !== APP_DOMAIN)
    {
      $scope.isMasterApp = false;
      $api.get('/info/domain',{
        app_name : location.hostname + ''
      },null).then(function(resp){
        if(resp){
          if(resp.status){
            $scope.appName = resp.data.app_name;
          }
        }
        console.log(resp);
      });
    }


    $scope.logout = function(){
      $api.delete('/auth').then(function(data){
        console.log(data);
        if(data){
          if(data.status){
            ngToast.info('Logged out successfully');
            $rootScope.loginDetails = null;
            localStorage.removeItem('_loginDetails');
            $location.path('/logout');
          }
          else{
            $rootScope.loginDetails = null;
            localStorage.removeItem('_loginDetails');
            $location.path('/logout');
          }
        }
        else{
          $rootScope.loginDetails = null;
          localStorage.removeItem('_loginDetails');
          $location.path('/logout');
        }
      });

    };


    $timeout(function(){
      angular.element('#loader-container').addClass('hidden');
      angular.element('nav').removeClass('hidden');
      angular.element('#wrapper').removeClass('hidden');
      angular.element('.footer').removeClass('hidden');
    },500);

  }]);
