'use strict';

/**
 * @ngdoc function
 * @name icuttApp.controller:ProfileDnsCtrl
 * @description
 * # ProfileDnsCtrl
 * Controller of the icuttApp
 */
angular.module('icuttApp')
  .controller('ProfileDnsCtrl', ['$rootScope','$scope','$api','$loginDetails','$location',
    function ($rootScope,$scope,$api,$loginDetails,$location) {
      $scope.dnsList = [];

      $api.get('/info/dns').then(function(resp){
        if(resp){
          if(resp.status && resp.data){
            $scope.dnsList = resp.data;
          }
        }
      });

    }]);
