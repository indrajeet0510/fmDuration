'use strict';

/**
 * @ngdoc function
 * @name icuttApp.controller:ProfileDomainModalEditCtrl
 * @description
 * # ProfileDomainModalEditCtrl
 * Controller of the icuttApp
 */

angular.module('icuttApp').controller('ProfileDomainModalEditCtrl', ['$scope','$api','ngToast','$modalInstance',
  function ($scope,$api,ngToast, $modalInstance) {


  var vFlag  = true;

  $scope.appName = "";
  $scope.domainName = "";
  $scope.error = {};

  $scope.ok = function () {
      if(!$scope.appName) {
        $scope.error.appName = 'App Name cannot be empty';
        vFlag *= false;
      }
      if(!validator.isFQDN($scope.domainName)){
      //if(!/^(http(s)?\/\/:)?(www\.)?[a-zA-Z\-]{3,}(\.(com|net|org))?$/.test($scope.domainName)){
        $scope.error.domain = 'Invalid domain name';
        vFlag *= false;
      }
      if(vFlag){
        $scope.createDomain();
      }
  };

  $scope.createDomain = function(){
    $api.post('/domain',null,{
      domain : $scope.domainName,
      app_name : $scope.appName
    }).then(function(resp){
      if(resp){
        if(resp.status){
          ngToast.success('Domain created successfully');
          $modalInstance.close(resp.data);
        }
        else{
          $scope.error.appName = resp.error.app_name;
          $scope.error.domain = resp.error.domain;
          ngToast.danger('An error occurred ! Please check the errors below');
        }
      }
      else{
        ngToast.danger('An error occurred ! Please check the errors below');
      }
    },function(){

    });
  };

  $scope.cancel = function () {
    $modalInstance.dismiss('cancel');
  };
}]);
