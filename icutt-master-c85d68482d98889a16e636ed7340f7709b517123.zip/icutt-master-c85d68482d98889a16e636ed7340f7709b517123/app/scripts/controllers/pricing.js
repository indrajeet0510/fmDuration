'use strict';

/**
 * @ngdoc function
 * @name icuttApp.controller:PricingCtrl
 * @description
 * # PricingCtrl
 * Controller of the icuttApp
 */
angular.module('icuttApp')
  .controller('PricingCtrl', ['$rootScope','$scope','$api','$loginDetails','$location',
    function ($rootScope,$scope,$api,$loginDetails,$location) {

    }]);
