'use strict';

/**
 * @ngdoc function
 * @name iCuttFrontApp.directive:MerchantListCtrl
 * @description
 * # decimalsOnly
 * Directive of the iCuttFrontApp
 */

angular.module('iCuttFrontApp').directive('numbersOnly', function(){
  return {
    link : function(scope,element,attrs,model){
      element.on('keypress',function(e){
        if((e.which < 48 || e.which > 57)){
          if(e.which == 0 || e.which == 8){
          }
          else{
            return false;
          }
        }
      });
    }
  };
});
