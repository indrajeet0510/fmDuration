'use strict';

angular.module('iCuttFrontApp').directive('isEmailAvailable',function($q,Authentication){
  return {
    require : '?ngModel',
    restrict : 'A',
    scope : {
      userType : '='
    },
    link: function($scope, $element, $attrs, ngModel){

      ngModel.$asyncValidators.isEmailAvailable = function(modelValue, viewValue) {
        var email = modelValue || viewValue;
        return Authentication.isEmailAvailable($scope.userType,email).then(function(){
          return true;
        },function(reason){
          return $q.reject(reason);
        });
      };

      $scope.$watch('userType',function(){
        ngModel.$validate();
      });

    }
  };
});

