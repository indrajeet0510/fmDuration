'use strict';

angular.module('iCuttFrontApp').directive('isMobileAvailable',function($q,Authentication){
  return {
    require : '?ngModel',
    restrict : 'A',
    scope : {
      userType : '=',
      isdMobile :  '='
    },
    link: function($scope, $element, $attrs, ngModel){

      ngModel.$asyncValidators.isMobileAvailable = function(modelValue, viewValue) {
        var mobileNumber = modelValue || viewValue;
        return Authentication.isMobileAvailable($scope.userType,$scope.isdMobile,mobileNumber).then(function(){
          return true;
        },function(reason){
          return $q.reject(reason);
        });
      };

      $scope.$watch('userType',function(){
        ngModel.$validate();
      });

      $scope.$watch('isdMobile',function(){
        ngModel.$validate();
      });
    }
  };
});

