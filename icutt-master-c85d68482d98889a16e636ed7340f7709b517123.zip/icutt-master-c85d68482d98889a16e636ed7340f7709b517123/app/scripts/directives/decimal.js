'use strict';

/**
 * @ngdoc function
 * @name iCuttFrontApp.directive:MerchantListCtrl
 * @description
 * # decimalsOnly
 * Directive of the iCuttFrontApp
 */

angular.module('iCuttFrontApp').directive('decimalsOnly',function(){
  return {
    link : function(scope,element,attrs,model){
      element.on('keypress',function(e){
        if((e.which < 48 || e.which > 57) && e.which !== 46){
          if(e.which == 0 || e.which == 8){
          }
          else{
            return false;
          }
        }
        else if(e.which == 46){
          var elemval = element.val();
          if(elemval.split('').indexOf('.') !== -1){
            return false;
          }
        }

      });
    }
  };
});
