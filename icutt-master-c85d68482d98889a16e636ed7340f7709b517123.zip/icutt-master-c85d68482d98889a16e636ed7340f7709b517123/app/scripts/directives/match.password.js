'use strict';

angular.module('iCuttFrontApp').directive('matchPassword',function(){
  return {
    require : '?ngModel',
    restrict : 'A',
    scope : {
      matchPassword : '='
    },
    link: function($scope, $element, $attrs, ngModel){

      ngModel.$validators.matchPassword = function(modelValue) {
        return ($scope.matchPassword == modelValue);
      };

      $scope.$watch('matchPassword',function(password){
        ngModel.$validate();
      });
    }
  };
});
