'use strict';

angular.module('iCuttFrontApp')
  .factory('Authentication',function($http,$q,$window,$timeout,UtilitySvc,API_URL){

    var userInfo;

    // Loads data from localStorage to Authentication Service
    function init(){
      if ($window.localStorage["userInfo"]) {
        try{
          userInfo = ($window.localStorage["userInfo"]) ? JSON.parse($window.localStorage["userInfo"]) : null;
        }
        catch(ex){
          userInfo = null;
        }

      }
    }

    function isEmailAvailable(userType,email){
      var deferred = $q.defer();
      $http({
        url : API_URL + 'check_email_availability',
        method : HTTP.GET,
        params : {
          email : email,
          userType : userType
        }
      }).then(function(resp) {
        console.log('check_email_availability',resp);
        if (resp && resp.data && resp.data.status) {
          deferred.resolve();
        }
        else{
          deferred.reject(resp.data.message);
        }
      },function(){
        deferred.reject('Unable to check availability');
      });
      return deferred.promise;
    }

    function isMobileAvailable(userType,isdMobile,mobile){
      var deferred = $q.defer();
      $http({
        url : API_URL + 'check_mobile_availability',
        method : HTTP.GET,
        params : {
          userType : userType,
          isdMobile : isdMobile,
          mobile : mobile
        }
      }).then(function(resp) {
        console.log('check_mobile_availability',resp.data.status);
        if (resp && resp.data && resp.data.status) {
          deferred.resolve();
        }
        else{
          deferred.reject(resp.data.message);
        }
      },function(){
        deferred.reject('Unable to check availability');
      });
      return deferred.promise;
    }

    function getRemoteUserInfo(){
      var deferred = $q.defer();
      console.log(userInfo);
      if(!userInfo){
        $timeout(function(){
          deferred.reject();
        },100);
        return deferred.promise;
      }

      $http({
        url : API_URL + 'user/detail',
        method : HTTP.GET,
      }).then(function(resp){
        if(resp && resp.data){
          console.log(resp);
          userInfo.jobSeekerResult = resp.data.data.jobSeekerResult;
          userInfo.loginResult = resp.data.data.loginResult;
          userInfo.employerResult = resp.data.data.employerResult;
          userInfo.operatorResult = resp.data.data.operatorResult;
          deferred.resolve(resp);
        }
        else{
          /**
           * Something went wrong ! Why response is not coming properly
           */
          console.log(resp);
          deferred.resolve(resp);

        }
      },function(err){
        /**
         * Some server issue, connectivity issue or something really bad happened
         */
        console.log(err);
        deferred.reject();
      });

      return deferred.promise;
    }

    function register(newUserData){
      var deferred = $q.defer();
      switch (newUserData.userType) {
        case 1 :
          // User is registering as a jobseeker

          $http({
            url : API_URL + "signup",
            method : HTTP.POST,
            data : newUserData
          }).then(function(resp){
            if(resp && resp.data && resp.data.status && resp.data.auth){
              userInfo = resp.data.data;
              userInfo.userType = newUserData.userType;
              $window.localStorage["userInfo"] = JSON.stringify(userInfo);
              deferred.resolve(userInfo);
            }
            else{
              deferred.reject(resp);
            }
          },function(err){
            deferred.reject(err);
          });

          break;
        case 2 :
          $http({
            url : API_URL + "signup",
            method : HTTP.POST,
            data : newUserData
          }).then(function(resp){
            if(resp && resp.data && resp.data.status && resp.data.auth){
              userInfo = resp.data.data;
              userInfo.userType = newUserData.userType;
              $window.localStorage["userInfo"] = JSON.stringify(userInfo);
              deferred.resolve(userInfo);
            }
            else{
              deferred.reject(resp);
            }
          },function(err){
            deferred.reject(err);
          });
          break;
        default :
          // Default (No action)
          deferred.reject();
          break;
      }
      return deferred.promise;
    }

    function login(loginData){

      var deferred = $q.defer();

      $http({
        url : API_URL + "login",
        method : HTTP.POST,
        data : loginData
      }).then(function(resp) {
        console.log('loginResult',resp.data.data);
        if(resp && resp.data && resp.data.status && resp.data.auth){
          userInfo = resp.data.data;
          userInfo.userType = loginData.userType;
          $window.localStorage["userInfo"] = JSON.stringify(userInfo);
          deferred.resolve(userInfo);
        }
        else{
          deferred.reject(resp);
        }
      }, function(error) {
        deferred.reject(error);
      });

      return deferred.promise;
    }

    function logout(){
      var deferred = $q.defer();
      $http({
        url : API_URL + "logout",
        method : HTTP.POST,
        params : {
          __jwToken : userInfo.sessionResult[0].__jwToken
        }
      }).then(function(resp){
        console.log(resp.data);
        if(resp && resp.data && resp.data.status){
          userInfo = null;
          $window.localStorage["userInfo"] = undefined;
          deferred.resolve(userInfo);
        }
        else{
          deferred.reject({ reason : resp});
        }
      },function(error){
        deferred.reject(error);
      });
      return deferred.promise;
    }

    function getUserInfo(){
      return userInfo;
    }

    /**
     * Operator registering job seeker
     * @param jobSeekerDetails
     */
    function oRegisterJobSeeker(jobSeekerDetails){
      var deferred = $q.defer();
      $http({
        url : API_URL + 'o/jobseeker/signup',
        method : HTTP.POST,
        data : jobSeekerDetails
      }).then(function(resp){
        UtilitySvc.parseSuccessResponse(resp,deferred);
      },function(err){
        UtilitySvc.parseSuccessResponse(resp,deferred);
      });
      return deferred.promise;
    }

    /**
     * Operator registering employer
     * @param employerDetails
     */
    function oRegisterEmployer(employerDetails){
      var deferred = $q.defer();
      $http({
        url : API_URL + 'o/employer/signup',
        method : HTTP.POST,
        data : employerDetails
      }).then(function(resp){
        UtilitySvc.parseSuccessResponse(resp,deferred);
      },function(err){
        UtilitySvc.parseSuccessResponse(resp,deferred);
      });
      return deferred.promise;
    }

    init();
    return {
      register : register,
      login : login,
      logout : logout,
      getUserInfo : getUserInfo,
      getRemoteUserInfo : getRemoteUserInfo,
      isEmailAvailable : isEmailAvailable,
      isMobileAvailable : isMobileAvailable,

      oRegisterJobSeeker : oRegisterJobSeeker,
      oRegisterEmployer : oRegisterEmployer,
    };

  });
