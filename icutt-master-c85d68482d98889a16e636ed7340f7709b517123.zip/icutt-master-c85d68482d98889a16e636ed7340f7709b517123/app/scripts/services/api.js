/**
 * Created by Indra on 19-07-2015.
 */

(function(){
  angular.module('icuttApp').service('$api',['$q','$http','API_URL','$responseParser',
    function($q,$http,API_URL,$responseParser){
    return {
        get : function(url,params,data,headers,transformRequest){
          var defer = $q.defer();
          var httpOpt = {};
          httpOpt.url = API_URL + url;
          httpOpt.method = 'GET';
          httpOpt.params = (params) ? params : null;

          if(headers){
            httpOpt.headers = headers;
          }

          if(transformRequest){
            httpOpt.transformRequest = transformRequest;
          }

          console.log(httpOpt);
          $http(httpOpt).success(function(resp,statusCode,respHeaders,config){
            defer.resolve($responseParser(resp,statusCode,respHeaders,config));
          }).error(function(err,statusCode,respHeaders,config){
            defer.resolve($responseParser(err,statusCode,respHeaders,config));
          });

          return defer.promise;
        },
        post : function(url,params,data,headers,transformRequest){
          var defer = $q.defer();
          var httpOpt = {};
          httpOpt.url = API_URL + url;
          httpOpt.method = 'POST';
          httpOpt.params = params;
          httpOpt.data = data;

          if(headers){
            httpOpt.headers = headers;
          }

          if(transformRequest){
            httpOpt.transformRequest = transformRequest;
          }

          $http(httpOpt).success(function(resp,statusCode,respHeaders,config){
            defer.resolve($responseParser(resp,statusCode,respHeaders,config));
          }).error(function(err,statusCode,respHeaders,config){
            defer.resolve($responseParser(err,statusCode,respHeaders,config));
          });

          return defer.promise;

        },
        put : function(url,params,data,headers,transformRequest){
          var defer = $q.defer();
          var httpOpt = {};
          httpOpt.url = API_URL + url;
          httpOpt.method = 'PUT';
          httpOpt.params = params;
          httpOpt.data = data;

          if(headers){
            httpOpt.headers = headers;
          }

          if(transformRequest){
            httpOpt.transformRequest = transformRequest;
          }

          $http(httpOpt).success(function(resp,statusCode,respHeaders,config){
            defer.resolve($responseParser(resp,statusCode,respHeaders,config));
          }).error(function(err,statusCode,respHeaders,config){
            defer.resolve($responseParser(err,statusCode,respHeaders,config));
          });

          return defer.promise;

        },
        delete : function(url,params,data,headers,transformRequest){
          var defer = $q.defer();
          var httpOpt = {};
          httpOpt.url = API_URL + url;
          httpOpt.method = 'DELETE';
          httpOpt.params = params;
          httpOpt.data = data;

          if(headers){
            httpOpt.headers = headers;
          }

          if(transformRequest){
            httpOpt.transformRequest = transformRequest;
          }

          $http(httpOpt).success(function(resp,statusCode,respHeaders,config){
            defer.resolve($responseParser(resp,statusCode,respHeaders,config));
          }).error(function(err,statusCode,respHeaders,config){
            defer.resolve($responseParser(err,statusCode,respHeaders,config));
          });
          return defer.promise;
        }
    };
  }]);
})();
