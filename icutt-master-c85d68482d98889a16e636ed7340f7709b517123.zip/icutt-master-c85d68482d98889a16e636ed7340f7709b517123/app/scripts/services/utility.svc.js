'use strict';

/**
 * @ngdoc function
 * @name iCuttFrontApp.factory:UtilitySvc
 * @description
 * # UtilitySvc
 * Factory of the iCuttFrontApp
 */

angular.module('iCuttFrontApp').factory('UtilitySvc',function($mdToast,$http,$q,$mdDialog,API_URL) {

  /**
   * Parses success response and gives a toast if requested
   * If toast is not required then pass noToastFlag as true
   * @param resp
   * @param deferred
   * @param noToastFlag
   */
  function parseSuccessResponse(resp, deferred, noToastFlag) {
    if (resp && resp.data && resp.data.status) {

      if (!noToastFlag) {
        $mdToast.show(
          $mdToast.simple()
            .textContent(resp.data.message)
            .parent(angular.element('#toastContainer'))
            .position('bottom right')
            .hideDelay(3000)
            .theme('success-toast')
        );
      }
      deferred.resolve(resp.data);

    }
    else if (resp && resp.data && resp.data.message && resp.status === 200) {
      $mdToast.show(
        $mdToast.simple()
          .textContent(resp.data.message)
          .parent(angular.element('#toastContainer'))
          .position('bottom right')
          .hideDelay(3000)
          .theme('danger-toast')
      );
      deferred.reject(resp);
    }
  }

  /**
   * Parses error response and gives error toast
   * @param err
   * @param deferred
   */
  function parseErrorResponse(err,deferred){
    console.debug(err);


    if(err && err.status &&  err.status != -1){
      $mdToast.show(
        $mdToast.simple()
          .textContent('Something went wrong ! Please try again')
          .parent(angular.element('#toastContainer'))
          .position('bottom right' )
          .hideDelay(3000)
          .theme('danger-toast')
      );

      deferred.reject(err);
    }
    else if(err && err.status === -1){
      $mdToast.show(
        $mdToast.simple()
          .textContent('Please check your connectivity and try again !')
          .parent(angular.element('#toastContainer'))
          .position('bottom right' )
          .hideDelay(3000)
          .theme('warning-toast')
      );

      deferred.reject(err);
    }
  }



  function showConfirmationDialog(ev,message,enableFlag) {
    // Appending dialog to document.body to cover sidenav in docs app

    var deferred = $q.defer();

    var confirm = $mdDialog.confirm()
      .title('Confirmation?')
      .textContent((message) ? message : 'Are you sure you want to '+ ((enableFlag) ? 'enable' : 'disable') +' this user?')
      .targetEvent(ev)
      .ok('Yes')
      .cancel('No');

    $mdDialog.show(confirm).then(function() {
      deferred.resolve();
    }, function() {
      deferred.reject();
    });

    return deferred.promise;
  }


  return {
    parseSuccessResponse : parseSuccessResponse,
    parseErrorResponse : parseErrorResponse,
    showConfirmationDialog : showConfirmationDialog
  };


});
