'use strict';

/**
 * @ngdoc function
 * @name iCuttFrontApp.factory:SessionSvc
 * @description
 * # SessionSvc
 * Factory of the iCuttFrontApp
 */

angular.module('iCuttFrontApp').factory('SessionSvc',function($injector) {
  return {
    request: function (config) {
      var Authentication = $injector.get('Authentication');
      if(Authentication.getUserInfo()) {
        config.headers['x-access-token'] = Authentication.getUserInfo().sessionResult[0].__jwToken;
      }
      return config;
    }
  };
});
