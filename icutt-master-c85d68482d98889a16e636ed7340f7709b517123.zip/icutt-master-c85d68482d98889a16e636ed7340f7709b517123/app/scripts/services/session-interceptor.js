'use strict';

/**
 * @ngdoc function
 * @name icuttApp.factory:SessionInjector
 * @description
 * # SessionInjector
 * Factory of the icuttApp
 */

(function(){
  angular.module('icuttApp').factory('SessionInterceptor', ['$rootScope','$q','$injector','$location','API_URL',
    function($rootScope,$q,$injector,$location,API_URL) {
      return {
        request: function(config) {
          if ($rootScope.loginDetails) {
            config.headers['access_token'] = $rootScope.loginDetails.access_token;
          }
          return config;
        },
        responseError : function(resp){
          console.log(resp);
          //{"data":null,"status":0,"config":{"method":"POST","transformRequest":[null],"transformResponse":[null],"url":"http://localhost:3000/api/auth","params":null,"data":{"email":"abc@gmail.com","password":"123456"},"headers":{"Accept":"application/json, text/plain, */*","Content-Type":"application/json;charset=utf-8"}},"statusText":""}

          if(resp.status === 401 && resp.statusText === 'Unauthorized'){
            var deferred = $q.defer();

            $injector.get('$http')({
              method : 'GET',
              url : API_URL+'/auth/refresh',
              headers : {
                refresh_token : ($rootScope.loginDetails) ? $rootScope.loginDetails.refresh_token : null
              }
            }).then(function(authResp){

              if(authResp.data && authResp.data.status){

                $rootScope.loginDetails.access_token = authResp.data.access_token;
                $rootScope.loginDetails.refresh_token = authResp.data.refresh_token;
                resp.config.headers.access_token = authResp.data.access_token;
                localStorage.setItem('_loginDetails',JSON.stringify($rootScope.loginDetails));

                $injector.get('$http')(resp.config).then(function(response){
                  deferred.resolve(response);
                },function(response){
                  $rootScope.loginDetails = undefined;
                  localStorage.removeItem('_loginDetails');
                  deferred.reject(response);
                  // $location.path('/login');
                });

              }
              else{
                $rootScope.loginDetails = undefined;
                localStorage.removeItem('_loginDetails');
                deferred.reject(authResp);
                // $location.path('/login');
              }

            },function(authRej){
              $rootScope.loginDetails = undefined;
              localStorage.removeItem('_loginDetails');
              deferred.reject(authRej);
              // $location.path('/login');
            });

            return deferred.promise;
          }
          else{
            return $q.reject(resp);
          }
        }
      };
    }]);
})();
