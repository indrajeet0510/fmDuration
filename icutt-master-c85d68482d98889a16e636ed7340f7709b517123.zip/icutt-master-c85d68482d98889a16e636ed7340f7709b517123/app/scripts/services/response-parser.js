/**
 * Created by Indra on 19-07-2015.
 */
(function(){
  angular.module('icuttApp').factory('$responseParser', ['ngToast', function(ngToast) {

    return function(resp,statusCode,respHeaders,config) {
      if(statusCode === 0){
        console.log('Unable to reach the server');
        ngToast.create({
          className: 'warning',
          content: '<h5>Connection Lost</h5> Unable to reach server'
        });
      }
      if(statusCode === 200){
        console.log('Resource loaded');
      }

      if(statusCode === 201){
        console.log('Resource Created');
      }

      if(statusCode === 204){
        console.log('Requested completed with no content');
      }

      if(statusCode === 400){
        console.log('Error occurred ! Please check the request');
      }

      if(statusCode === 404){
        console.log('Resource not found');
      }

      if(statusCode === 500){
        console.log('Service encountered a problem ! Please try again');
      }

      return resp;

    };
  }]);
})();
