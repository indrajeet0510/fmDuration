'use strict';

angular.module('iCuttFrontApp')

  // API URL
  .constant("API_URL","http://localhost:3000/api/")
  .constant("STATIC_URL","")
  .constant("DEFAULT_IMAGE_URL","https://s-media-cache-ak0.pinimg.com/564x/0d/d7/bf/0dd7bffbf3b184d7b7fb61974442806e.jpg")

  // Not used right now but soon be referenced in whole app
  .constant("API_PATH",{
      REGISTER : 'register',
      LOGIN : 'login',
      LOGOUT : 'logout'
  });
