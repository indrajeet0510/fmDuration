'use strict';

angular.module('iCuttFrontApp')


  .run(function run($rootScope, $state, Authentication) {

    $rootScope.$on("$stateChangeStart",
      function(event, toState, toParams, fromState, fromParams) {
        console.log('toState',toState);
        /**
         * If user is not logged in send him to login(landing) page
         */
        if (toState.authState && toState.authenticate && !Authentication.getUserInfo()) {
          $state.go("login");
          event.preventDefault();
        }

        /**
         * If user is logged in and try to go to the URL which is secured
         */
        else if(toState.authState && toState.authenticate && Authentication.getUserInfo()){

          /**
           * Check if user is having permission to go to that state and if he don't have permission then redirect him to respective home url based on his userType
           */
          if(toState.allowedUserTypes && toState.allowedUserTypes.indexOf(Authentication.getUserInfo().userType) == -1){
            switch (Authentication.getUserInfo().userType){
              case 1:
                $state.go("home");
                break;
              case 2:
                $state.go("customer.home");
                break;
              case 3:
                $state.go("operator.home");
                break;
              default:
                $state.go("home");
            }
            event.preventDefault();
          }
          /**
           * Check if user is having permission to go to that state then don't stop him let him access the URL
           */
          else{

          }

        }

        else if(toState.authState && (!toState.authenticate) && Authentication.getUserInfo()){

            switch (Authentication.getUserInfo().userType){
              case 1:
                $state.go("home");
                break;
              case 2:
                $state.go("customer.home");
                break;
              case 3:
                $state.go("operator.home");
                break;
              default:
                $state.go("home");
            }
            event.preventDefault();
        }
      });

    /**
     * Set current state in $rootScope after stateChange event has successfully took place
     */
    $rootScope.$on("$stateChangeSuccess",function(event, toState, toParams, fromState, fromParams){
      $rootScope.currentState = toState;
      // $rootScope.currentState.name is the actual state name
    });


  });
