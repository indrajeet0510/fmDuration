'use strict';

angular.module('iCuttFrontApp')

  .config(function ($stateProvider,$urlRouterProvider,$mdThemingProvider,$mdIconProvider,$httpProvider,$compileProvider,$mdToastProvider,$mdDateLocaleProvider) {

    /**
     * For whitelisting the necessary URLs so that they could work properly
     */
    $compileProvider.aHrefSanitizationWhitelist(/^\s*(https?|ftp|mailto|tel|chrome-extension):/);

    /**
     * Defining a custom palette for material design
     */
    $mdThemingProvider.definePalette('operatorPalette', {
      '50': 'E0F7FA',
      '100': 'B2EBF2',
      '200': '80DEEA',
      '300': '4DD0E1',
      '400': '26C6DA',
      '500': '00BCD4',
      '600': '00ACC1',
      '700': '0097A7',
      '800': '00838F',
      '900': '006064',
      'A100': '84FFFF',
      'A200': '18FFFF',
      'A400': '00E5FF',
      'A700': '00B8D4',
      'contrastDefaultColor': 'light',    // whether, by default, text (contrast)
                                          // on this palette should be dark or light

      'contrastDarkColors': ['50', '100', //hues which contrast should be 'dark' by default
        '200', '300', '400', 'A100'],
      'contrastLightColors': undefined    // could also specify this if default was 'dark'
    });


    /**
     * Theme declaration
     */

    var customBlueMap = 		$mdThemingProvider.extendPalette('light-blue', {
      'contrastDefaultColor': 'light',
      'contrastDarkColors': ['50'],
      '50': 'ffffff'
    });
    $mdThemingProvider.definePalette('customBluePalette', customBlueMap);

    $mdThemingProvider.theme('default')
      .primaryPalette('customBluePalette')
      .accentPalette('grey');

    $mdThemingProvider.theme('greenThemeDark')
      .primaryPalette('green').dark();

    $mdThemingProvider.theme('greenTheme')
      .primaryPalette('green');

    $mdThemingProvider.theme('greyTheme')
      .primaryPalette('grey');

    $mdThemingProvider.theme('blueTheme')
      .primaryPalette('blue').dark();

    $mdThemingProvider.theme('redTheme')
      .primaryPalette('red');

    $mdThemingProvider.theme('operatorTheme')
      .primaryPalette('operatorPalette');

    $mdThemingProvider.theme('operatorDarkTheme')
      .primaryPalette('operatorPalette').dark();

    $mdThemingProvider.theme("success-toast");
    $mdThemingProvider.theme("danger-toast");
    $mdThemingProvider.theme("warning-toast");
    $mdThemingProvider.theme("primary-toast");

    $mdIconProvider.fontSet('md', 'material-icons');


    /**
     * Custom theme for search boxes
     */

    var customBlueMap = 		$mdThemingProvider.extendPalette('light-blue', {
      'contrastDefaultColor': 'light',
      'contrastDarkColors': ['50'],
      '50': 'ffffff'
    });
    $mdThemingProvider.definePalette('customBluePalette', customBlueMap);
    $mdThemingProvider.theme('customBlueTheme')
      .primaryPalette('customBluePalette', {
        'default': '500',
        'hue-1': '50'
      })
      .accentPalette('pink');

    /**
     * Route configurations
     */
    $stateProvider

    // ABOUT PAGE AND MULTIPLE NAMED VIEWS =================================
      .state('about', {
        url : '/about',
        templateUrl : 'modules/about/about.html',
        controller : 'AboutCtrl as aboutCtrl',
        authState : false
      })

      .state('forgot_password', {
        params: {
          ut : 1, // By default send userType as 1 otherwise pass it from the place where link is generated for this state eg. ui-sref="forgot_password({ ut: 1 })"
        },
        url : '/forgot_password',
        templateUrl : 'modules/password/forgot.password.html',
        controller : 'ForgotPasswordCtrl as forgotPasswordCtrl',
        authState : true,
        authenticate : false
      })

      .state('validate_otp', {
        params: {
          ut : 1, // By default send userType as 1 otherwise pass it from the place where link is generated for this state eg. ui-sref="forgot_password({ ut: 1 })"
        },
        url : '/validate_otp/{id}',
        templateUrl : 'modules/password/otp.verification.html',
        controller : 'OtpVerificationCtrl as otpVerificationCtrl',
        authState : true,
        authenticate : false
      })

      .state('reset_link', {

        url : '/reset_link/{resetCode}',
        templateUrl : 'modules/password/password.reset.html',
        controller : 'PasswordResetCtrl as passwordResetCtrl',
        authState : false
      })

      .state('register', {

        url : '/register',
        templateUrl : 'modules/auth/user-register.html',
        controller : 'UserRegisterCtrl as userRegisterCtrl',
        authState : false
      })

      .state('landing',{
        url : '/landing',
        templateUrl : 'modules/auth/landing.html',
        controller : 'LandingCtrl as landingCtrl',
        authState : true,
        authenticate: false
      })

      .state('login',{
        url : '/login',
        templateUrl : 'modules/auth/user-login.html',
        controller : 'UserLoginCtrl as userLoginCtrl',
        authState : true,
        authenticate: false
      })


      /**
       * authState : This state has to check for authentication before navigation
       * authenticate : If this flag is true then user should be authenticated to access the state and if it is false then user should not be logged in otherwise he will not be able to navigate
       */

      .state('home', {
        url: '/user',
        templateUrl: 'modules/enduser/user-home.html',
        controller : 'UserHomeCtrl as userHomeCtrl',
        authState : true,
        authenticate: true,
        allowedUserTypes : [1],
        resolve : {
          // latestUserInfo : function(Authentication){
          //   return Authentication.getRemoteUserInfo();
          // }
        }
      })

      .state('home.profile', {
        url : '/profile',
        templateUrl : 'modules/enduser/profile/profile.html',
        controller : 'ProfileCtrl as profileCtrl',
        authState : true,
        allowedUserTypes :  [1],
        authenticate : true
      })

      .state('home.change_password', {
        url : '/change_password',
        templateUrl : 'modules/password/change.password.html',
        controller : 'ChangePasswordCtrl as changePasswordCtrl',
        authState : true,
        allowedUserTypes :  [1],
        authenticate : true
      })

      //Customer States

      .state('customer', {

        url : '/customer',
        template : '<div style="min-height: inherit;" ui-view=""></div>',
        authState : false,
        abstract : true
      })

      .state('customer.register', {
        url : '/register',
        templateUrl : 'modules/auth/customer-register.html',
        controller : 'CustomerRegisterCtrl as customerRegisterCtrl',
        authState : false
      })

      .state('customer.login', {
        url : '/login',
        templateUrl : 'modules/auth/customer-login.html',
        controller : 'CustomerLoginCtrl as customerLoginCtrl',
        authState : false
      })

      .state('customer.home',{
        url : '/home',
        templateUrl : 'modules/customer/customer-home.html',
        controller : 'CustomerHomeCtrl as customerHomeCtrl',
        authState : true,
        authenticate : true,
        allowedUserTypes : [2]
      })

      .state('customer.home.profile',{
        url : '/profile',
        templateUrl : 'modules/customer/profile/customer-profile.html',
        controller : 'CustomerHomeProfileCtrl as customerHomeProfileCtrl',
        authState : true,
        authenticate : true,
        allowedUserTypes : [2]
      })


      .state('customer.home.change_password', {
        url : '/change_password',
        templateUrl : 'modules/password/change.password.html',
        controller : 'ChangePasswordCtrl as changePasswordCtrl',
        authState : true,
        allowedUserTypes :  [2],
        authenticate : true
      })

      //Operator States

      .state('operator', {

        url : '/operator',
        template : '<div style="min-height: inherit;" ui-view=""></div>',
        authState : false,
        abstract : true
      })

      .state('operator.login', {
        url : '/login',
        templateUrl : 'modules/auth/operator.login.html',
        controller : 'OperatorLoginCtrl as operatorLoginCtrl',
        authState : false
      })

      .state('operator.home',{
        url : '/home',
        templateUrl : 'modules/operator/operator.home.html',
        controller : 'OperatorHomeCtrl as operatorHomeCtrl',
        authState : true,
        authenticate : true,
        allowedUserTypes : [3]
      })

      .state('operator.home.change_password', {
        url : '/change_password',
        templateUrl : 'modules/password/change.password.html',
        controller : 'ChangePasswordCtrl as changePasswordCtrl',
        authState : true,
        allowedUserTypes :  [3],
        authenticate : true
      })



      .state('operator.home.customers',{
        url : '/customers',
        templateUrl : 'modules/operator/customers/operator.customers.html',
        controller : 'OCustomersCtrl as oCustomersCtrl',
        authState : true,
        authenticate : true,
        allowedUserTypes : [3],
        resolve : {
          InitialCustomerResult : function(OCustomersSvc){
            return OCustomersSvc.oSearchCustomers({
              keyword : '',
              status : 1, // 0 - ALL  , 1 – New (Lead), 2 – Active,3 - Inactive, 4 - Cancelled, 5 – Blocked
              pageNo : 1,
              limit : OCustomersSvc.oSearchCustomersLimit
            });
          }
        }
      })

      .state('operator.home.customers.new',{
        url : '/new',
        templateUrl : 'modules/enduser/primary.information/primary.information.html',
        controller : 'OEndUserNewCtrl as oEndUserNewCtrl',
        authState : true,
        authenticate : true,
        allowedUserTypes : [3]
      })

      .state('operator.home.customers.profile',{
        url : '/{entityId:[0-9]{1,8}}',
        templateUrl : 'modules/customer/profile/customer.profile.html',
        controller : 'OCustomerHomeProfileCtrl as oCustomerHomeProfileCtrl',
        authState : true,
        authenticate : true,
        allowedUserTypes : [3],
        resolve : {
          CustomerDetails : function($q,CustomerSvc,$stateParams) {
            var deferred = $q.defer();

            CustomerSvc.oLoadCustomerDetails($stateParams.entityId).then(function(resp){
              deferred.resolve(resp.data);
            });

            return deferred.promise;
          }
        }
      })



      .state('operator.home.enduser',{
        url : '/enduser',
        templateUrl : 'modules/operator/enduser/operator.enduser.home.html',
        controller : 'OEndUserCtrl as oEndUserCtrl',
        authState : true,
        authenticate : true,
        allowedUserTypes : [3],
        resolve : {
          InitialEndUserResult : function(OEndUserSvc){
            return OEndUserSvc.oSearchEndUser({
              keyword : '',
              qcCheck : 1, // 1 - QC Pending Checked and 2 - QC Pending unchecked
              cvOrder : 1, // 1 - Oldest First and 2 - Latest First
              pageNo : 1,
              limit : OEndUserSvc.oSearchEndUserLimit
            });
          }
        }
      })
      .state('operator.home.enduser.profile.primary',{
        url : '/primary_info',
        templateUrl : 'modules/enduser/primary.information/primary.information.html',
        controller : 'OEndUserPrimaryCtrl as oEndUserPrimaryCtrl',
        authState : true,
        authenticate : true,
        allowedUserTypes : [3]
      })
      .state('operator.home.enduser.profile.personal',{
        url : '/personal_info',
        templateUrl : 'modules/enduser/personal.information/personal.information.html',
        controller : 'OEndUserPersonalCtrl as oEndUserPersonalCtrl',
        authState : true,
        authenticate : true,
        allowedUserTypes : [3]
      });
    /**
     * Attaches session variable before each API request which needs authentication
     */
    $httpProvider.interceptors.push('SessionSvc');

    $urlRouterProvider.otherwise('/landing');

  });
