/*SELECT @lid:=LAST_INSERT_ID();*/
SELECT @lid:= 3;
SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 1),
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@seed)*4294967296))*62+1, 1),
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@seed)*4294967296))*62+1, 1),
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@seed)*4294967296))*62+1, 1),
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@seed)*4294967296))*62+1, 1),
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@seed)*4294967296))*62+1, 1),
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@seed)*4294967296))*62+1, 1),
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@seed)*4294967296))*62+1, 1)
             ) AS str;
