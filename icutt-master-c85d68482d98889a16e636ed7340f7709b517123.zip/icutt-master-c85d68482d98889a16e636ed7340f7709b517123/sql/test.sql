/*SELECT @lid:=LAST_INSERT_ID();*/
SELECT @lid:= 1;
SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str1;
             SELECT @lid:= 2;
             SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str2;
             SELECT @lid:= 3;
             SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str3;
             SELECT @lid:= 4;
             SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str4;
             SELECT @lid:= 5;
             SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str5;
             SELECT @lid:= 6;
             SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str6;
             SELECT @lid:= 7;
             SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str7;             SELECT @lid:= 8;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str8;             SELECT @lid:= 9;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str9;             SELECT @lid:= 10;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str10;             SELECT @lid:= 11;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str11;             SELECT @lid:= 12;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str12;             SELECT @lid:= 13;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str13;             SELECT @lid:= 14;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str14;             SELECT @lid:= 15;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str15;             SELECT @lid:= 16;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str16;             SELECT @lid:= 17;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str17;             SELECT @lid:= 18;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str18;             SELECT @lid:= 19;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str19;             SELECT @lid:= 20;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str20;             SELECT @lid:= 21;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str21;             SELECT @lid:= 22;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str22;             SELECT @lid:= 23;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str23;             SELECT @lid:= 24;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str24;             SELECT @lid:= 25;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str25;             SELECT @lid:= 26;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str26;             SELECT @lid:= 27;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str27;             SELECT @lid:= 28;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str28;             SELECT @lid:= 29;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str29;             SELECT @lid:= 30;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str30;             SELECT @lid:= 31;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str31;             SELECT @lid:= 32;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str32;             SELECT @lid:= 33;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str33;             SELECT @lid:= 34;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str34;             SELECT @lid:= 35;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str35;             SELECT @lid:= 36;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str36;             SELECT @lid:= 37;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str37;             SELECT @lid:= 38;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str38;             SELECT @lid:= 39;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str39;             SELECT @lid:= 40;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str40;             SELECT @lid:= 41;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str41;             SELECT @lid:= 42;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str42;             SELECT @lid:= 43;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str43;             SELECT @lid:= 44;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str44;             SELECT @lid:= 45;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str45;             SELECT @lid:= 46;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str46;             SELECT @lid:= 47;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str47;             SELECT @lid:= 48;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str48;             SELECT @lid:= 49;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str49;             SELECT @lid:= 50;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str50;             SELECT @lid:= 51;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str51;             SELECT @lid:= 52;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str52;             SELECT @lid:= 53;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str53;             SELECT @lid:= 54;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str54;             SELECT @lid:= 55;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str55;             SELECT @lid:= 56;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str56;             SELECT @lid:= 57;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str57;             SELECT @lid:= 58;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str58;             SELECT @lid:= 59;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str59;             SELECT @lid:= 60;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str60;             SELECT @lid:= 61;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str61;             SELECT @lid:= 62;              SELECT concat(
              substring('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz', rand(@seed:=round(rand(@lid)*4294967296))*62+1, 2)
             ) AS str62;


;
